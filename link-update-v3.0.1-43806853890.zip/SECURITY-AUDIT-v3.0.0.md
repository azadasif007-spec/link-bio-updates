# LINK v3.0.0 — Security Audit

Audit date: 2026-11-15
Scope: source review of the PHP application, installer, authentication, uploads, backups, payment gateways/webhooks, analytics and OTA updater.

## Summary

This is a source-code security review, not a penetration test or independent certification. No production credentials, payment-provider accounts, Hostinger file permissions, reverse-proxy configuration or database contents were accessed.

## Changes included in v3.0.0

- Hardened OTA ZIP extraction: rejects absolute paths, traversal components, backslashes, NUL bytes, duplicate paths, protected directories, Unix symbolic links, excessive file counts, oversized entries, oversized expanded archives and extreme compression ratios.
- Tightened Cashfree webhook timestamp freshness from 24 hours to 5 minutes.
- Corrected Cashfree transaction reconciliation so local order references used in Cashfree callbacks can resolve the stored transaction.
- Limited inbound webhook payload size to 1 MiB.
- Strengthened Apache upload script-extension blocking.
- Kept database credentials, profile uploads and private storage outside distributable install and OTA packages.

## Reviewed controls

- Password hashes use PHP password_hash/password_verify.
- Admin forms use session-bound CSRF tokens.
- Login attempts are rate-limited by a keyed email/network identity hash.
- Session strict mode, HttpOnly and SameSite=Lax cookies are configured; inactivity timeout is 30 minutes.
- Optional TOTP MFA and one-time hashed recovery codes are implemented.
- SQL access is predominantly parameterized PDO.
- Output is HTML-escaped at render points.
- Avatar uploads are MIME/image checked, dimension-limited and size-limited; filenames are random.
- Payment gateway secrets are encrypted at rest with AES-256-GCM and an installation-derived key.
- Payment status changes rely on provider webhook signatures or server-side provider checks; UPI references are explicitly treated as unverified claims.
- Webhook event identifiers are stored with a unique constraint for idempotency.
- Private backups are installation-fingerprinted and profile image paths are allowlisted during restore.
- OTA manifests use RSA-SHA256 signatures and packages use SHA-256 checksums.

## Remaining risks / deployment requirements

1. Production testing required: run the installer on a fresh staging domain, test admin login, TOTP, uploads, backups and restore, QR, analytics, UPI and provider sandbox payments before using live payments.
2. Payment provider validation: confirm current Razorpay and Cashfree API/webhook event formats against the merchant's live dashboard and current provider documentation. A code review cannot certify settlement correctness.
3. Backup restore: test a full backup restore on a disposable copy before relying on backups. Keep off-site copies; server-local backups do not protect against hosting-account loss.
4. Host configuration: require HTTPS, current supported PHP (8.2+), PDO MySQL, cURL, OpenSSL and ZIP. Ensure Apache .htaccess overrides are enabled and config/, storage/ and uploads/ are not directly executable.
5. 2FA: enable TOTP immediately after installation and store recovery codes outside the hosting account.
6. Cron secret: treat the daily backup URL as a credential. Rotate it if exposed; avoid posting it in tickets or screenshots.
7. Rate limiting: login throttling is application/database based and can be affected by shared proxy IPs. A WAF or host-level rate limit is recommended.
8. Security headers: HSTS is enabled in the provided Apache config; verify HTTPS and headers on each target host. Consider a carefully tested Content-Security-Policy before enabling one because the current UI loads external fonts and payment SDK assets.
9. No multi-tenant isolation: each domain must have its own database, installation secret, admin password, uploads and backup storage. Do not point multiple domains at the same writable installation directory/database.
10. OTA trust key: the embedded public key is intentionally shared by official builds. Protect the private signing key and publishing token; rotate keys only with a planned trust-key migration.

## Release decision

Suitable as a self-hosted single-profile application for controlled installation and staging validation. Not represented as penetration-tested, audited by a third party, or production-certified. Do not enable live payment collection until provider sandbox and live webhook verification are completed.