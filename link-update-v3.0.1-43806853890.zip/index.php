<?php
declare(strict_types=1);
require_once __DIR__ . '/app/bootstrap.php';
require_once __DIR__ . '/app/analytics.php';

if (!link_app_installed()) { header('Location: install/'); exit; }

$profile = [];
foreach (['name','eyebrow','headline','bio','location','avatar','accent','theme','header_mark','header_label','footer_credit','footer_credit_url','font_heading','font_body','button_style','avatar_shape','profile_layout','background_style'] as $key) {
    $profile[$key] = link_setting($key, '');
}
$profile['avatar'] = $profile['avatar'] ?: 'assets/images/avatar-placeholder.svg';
$profile['accent'] = $profile['accent'] ?: '#c5a46d';
$profile['theme'] = $profile['theme'] ?: 'forest';
$profile['links'] = link_db()->query('SELECT id,label,url,description,is_active AS enabled FROM links ORDER BY sort_order,id')->fetchAll();
link_track_event('page_view');
$profile['socials'] = [];
$socialDefinitions = [
    'instagram' => ['label'=>'Instagram','mark'=>'IG','setting'=>'social_instagram'],
    'facebook' => ['label'=>'Facebook','mark'=>'f','setting'=>'social_facebook'],
    'linkedin' => ['label'=>'LinkedIn','mark'=>'in','setting'=>'social_linkedin'],
    'x' => ['label'=>'X','mark'=>'𝕏','setting'=>'social_x'],
    'youtube' => ['label'=>'YouTube','mark'=>'▶','setting'=>'social_youtube'],
    'tiktok' => ['label'=>'TikTok','mark'=>'♪','setting'=>'social_tiktok'],
    'telegram' => ['label'=>'Telegram','mark'=>'➤','setting'=>'social_telegram'],
];
foreach ($socialDefinitions as $social) {
    $url = trim(link_setting($social['setting'], ''));
    if ($url !== '' && filter_var($url, FILTER_VALIDATE_URL)
        && strtolower((string)parse_url($url, PHP_URL_SCHEME)) === 'https') {
        $profile['socials'][] = ['label'=>$social['label'], 'mark'=>$social['mark'], 'url'=>$url];
    }
}
$whatsapp = preg_replace('/\\D+/', '', link_setting('social_whatsapp', ''));
if ($whatsapp !== '' && strlen($whatsapp) >= 10 && strlen($whatsapp) <= 15) {
    $profile['socials'][] = ['label'=>'WhatsApp', 'mark'=>'WA', 'url'=>'https://wa.me/'.$whatsapp];
}

function e(?string $value): string { return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function favicon_for_url(string $url): string {
    $host = parse_url($url, PHP_URL_HOST);
    if (!is_string($host) || $host === '' || !filter_var($host, FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME)) {
        return '';
    }
    return 'https://www.google.com/s2/favicons?domain=' . rawurlencode(strtolower($host)) . '&sz=64';
}
$name = trim((string)($profile['name'] ?? 'Your Name'));
$links = array_values(array_filter($profile['links'], static fn($link) => !empty($link['enabled']) && filter_var($link['url'] ?? '', FILTER_VALIDATE_URL)));
$accent = (string)($profile['accent'] ?? '#c5a46d');
if (!preg_match('/^#[0-9a-fA-F]{6}$/', $accent)) { $accent = '#c5a46d'; }
$avatar = (string)($profile['avatar'] ?? 'assets/images/avatar-placeholder.svg');
$theme = in_array(($profile['theme'] ?? 'forest'), ['forest','midnight','light','ocean','royal','rose','sunset','slate'], true) ? $profile['theme'] : 'forest';
$headingFonts=['playfair'=>'Playfair Display','dm-sans'=>'DM Sans','manrope'=>'Manrope','poppins'=>'Poppins','montserrat'=>'Montserrat'];
$bodyFonts=['dm-sans'=>'DM Sans','manrope'=>'Manrope','poppins'=>'Poppins','montserrat'=>'Montserrat','lato'=>'Lato'];
$headingFont=$headingFonts[$profile['font_heading']??'playfair']??'Playfair Display';
$bodyFont=$bodyFonts[$profile['font_body']??'dm-sans']??'DM Sans';
$buttonStyle=in_array($profile['button_style']??'glass',['glass','solid','outline'],true)?$profile['button_style']:'glass';
$avatarShape=in_array($profile['avatar_shape']??'circle',['circle','rounded','square'],true)?$profile['avatar_shape']:'circle';
$profileLayout=in_array($profile['profile_layout']??'classic',['classic','compact','editorial'],true)?$profile['profile_layout']:'classic';
$backgroundStyle=in_array($profile['background_style']??'ambient',['ambient','plain','glow'],true)?$profile['background_style']:'ambient';
$fontQuery=rawurlencode($headingFont).':wght@400;500;600;700&family='.rawurlencode($bodyFont).':wght@400;500;600;700';
?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#10251f">
<meta name="description" content="<?= e((string)($profile['bio'] ?? '')) ?>">
<title><?= e($name) ?> — Links</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=<?= e($fontQuery) ?>&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/style.css?v=20261116-favicons">
</head>
<body class="theme-<?= e($theme) ?> layout-<?= e($profileLayout) ?> buttons-<?= e($buttonStyle) ?> avatar-<?= e($avatarShape) ?> background-<?= e($backgroundStyle) ?>" style="--accent:<?= e($accent) ?>;--heading-font:'<?= e($headingFont) ?>',serif;--body-font:'<?= e($bodyFont) ?>',sans-serif">
<div class="ambient ambient-one"></div><div class="ambient ambient-two"></div>
<main class="page-shell">
  <div class="topline"><span class="brand-mark"><?= e((string)($profile['header_mark'] ?: 'L')) ?><span>·</span></span><span class="topline-label"><?= e((string)($profile['header_label'] ?: 'MY DIGITAL SPACE')) ?></span><span class="topline-rule"></span></div>
  <section class="profile" aria-label="Profile">
    <div class="avatar-wrap"><img class="avatar" src="<?= e($avatar) ?>" alt="<?= e($name) ?> profile photo" onerror="this.src='assets/images/avatar-placeholder.svg'"><span class="avatar-ring"></span></div>
    <?php if (!empty($profile['eyebrow'])): ?><p class="eyebrow"><?= e((string)$profile['eyebrow']) ?></p><?php endif; ?>
    <h1><?= e($name) ?></h1>
    <?php if (!empty($profile['headline'])): ?><p class="headline"><?= e((string)$profile['headline']) ?></p><?php endif; ?>
    <?php if (!empty($profile['bio'])): ?><p class="bio"><?= e((string)$profile['bio']) ?></p><?php endif; ?>
    <?php if (!empty($profile['location'])): ?><p class="location"><span aria-hidden="true">⌖</span> <?= e((string)$profile['location']) ?></p><?php endif; ?>
  </section>
  <section class="links" aria-label="Important links">
    <?php foreach ($links as $i => $link): ?>
      <a class="link-card" href="go/<?= (int)$link['id'] ?>" target="_blank" rel="noopener noreferrer" style="--delay:<?= (int)$i * 65 ?>ms">
        <span class="link-icon" aria-hidden="true"><img class="link-favicon" src="<?= e(favicon_for_url((string)$link['url'])) ?>" alt="" loading="lazy" decoding="async" referrerpolicy="no-referrer" onload="this.nextElementSibling.hidden=true" onerror="this.hidden=true"><span class="link-fallback"><?= e(strtoupper(substr((string)($link['label'] ?? '↗'),0,1))) ?></span></span>
        <span class="link-copy"><strong><?= e((string)($link['label'] ?? 'Open link')) ?></strong><?php if (!empty($link['description'])): ?><small><?= e((string)$link['description']) ?></small><?php endif; ?></span>
        <span class="link-arrow" aria-hidden="true">↗</span>
      </a>
    <?php endforeach; ?>
    <?php if (!$links): ?><p class="empty-links">Your links will appear here soon.</p><?php endif; ?>
  </section>
  <?php if (!empty($profile['socials'])): ?><nav class="socials" aria-label="Social profiles"><?php foreach ($profile['socials'] as $social): ?><a href="<?= e($social['url']) ?>" target="_blank" rel="noopener noreferrer" aria-label="<?= e($social['label']) ?>" title="<?= e($social['label']) ?>"><?= e($social['mark']) ?></a><?php endforeach; ?></nav><?php endif; ?>
  <footer><span>ONE LINK. YOUR ENTIRE DIGITAL IDENTITY.</span><a class="footer-credit" href="privacy.php">PRIVACY</a><?php if (!empty($profile['footer_credit'])): ?><span class="footer-dot"></span><?php if (!empty($profile['footer_credit_url']) && filter_var($profile['footer_credit_url'], FILTER_VALIDATE_URL) && in_array(strtolower((string)parse_url($profile['footer_credit_url'], PHP_URL_SCHEME)), ['http','https'], true)): ?><a class="footer-credit" href="<?= e((string)$profile['footer_credit_url']) ?>" target="_blank" rel="noopener noreferrer"><?= e((string)$profile['footer_credit']) ?></a><?php else: ?><span><?= e((string)$profile['footer_credit']) ?></span><?php endif; ?><?php endif; ?></footer>
</main>
<script src="assets/js/app.js" defer></script>
</body></html>
