<?php
declare(strict_types=1);
require_once __DIR__.'/app/bootstrap.php';
require_once __DIR__.'/app/payment_gateways.php';
if(!link_app_installed()){http_response_code(404);exit;}
link_gateway_ensure_schema();
$provider=(string)($_GET['provider']??'');
if(!in_array($provider,['razorpay','cashfree'],true)||!link_gateway_ready($provider)){http_response_code(404);exit;}
$contentLength=(int)($_SERVER['CONTENT_LENGTH']??0);
if($contentLength>1048576){http_response_code(413);exit('Payload too large.');}
$raw=file_get_contents('php://input',false,null,0,1048577)?:'';
if(strlen($raw)>1048576){http_response_code(413);exit('Payload too large.');}
$headers=[];
foreach((function_exists('getallheaders')?getallheaders():[]) as $k=>$v)$headers[strtolower((string)$k)]=(string)$v;
if(!$headers){foreach($_SERVER as $k=>$v)if(str_starts_with($k,'HTTP_'))$headers[strtolower(str_replace('_','-',substr($k,5)))]=(string)$v;}
if(!link_gateway_verify_webhook($provider,$raw,$headers)){http_response_code(401);exit('Invalid signature.');}
$event=json_decode($raw,true);
if(!is_array($event)){http_response_code(400);exit('Invalid event.');}
$eventType=(string)($event['event']??$event['type']??$event['data']['type']??'unknown');
$eventKey=(string)($headers['x-razorpay-event-id']??$event['id']??'');
if($eventKey==='')$eventKey=hash('sha256',$raw);
$pdo=link_db();
try{
 $pdo->beginTransaction();
 $ins=$pdo->prepare('INSERT INTO gateway_webhook_events (provider,event_key,event_type) VALUES (?,?,?)');
 $ins->execute([$provider,substr($eventKey,0,190),substr($eventType,0,100)]);
 $updated=false;
 if($provider==='razorpay'){
  $link=$event['payload']['payment_link']['entity']??[];$payment=$event['payload']['payment']['entity']??[];
  $providerId=(string)($link['id']??'');$paymentId=(string)($payment['id']??'');$method=(string)($payment['method']??'');
  if($providerId!==''&&$eventType==='payment_link.paid'){
   $paidAmount=isset($link['amount_paid'])?(float)$link['amount_paid']/100:null;$currency=(string)($link['currency']??'INR');
   if($paymentId!=='')$updated=link_gateway_mark_paid('razorpay',$providerId,$paymentId,$method,$paidAmount,$currency);
  }elseif($eventType==='payment.refunded'){
   $refundLink=(string)($payment['payment_link_id']??$providerId);if($refundLink!=='')$updated=link_gateway_mark_refunded('razorpay',$refundLink,(string)($payment['id']??''));
  }elseif($providerId!==''&&in_array($eventType,['payment_link.expired','payment_link.cancelled'],true)){
   $updated=link_gateway_update_status('razorpay',$providerId,$eventType==='payment_link.expired'?'expired':'cancelled',$paymentId,$method);
  }
 }elseif($provider==='cashfree'){
  $data=$event['data']??[];$order=$data['order']??[];$payment=$data['payment']??[];
  $orderId=(string)($order['order_id']??'');$providerStatus=strtoupper((string)($payment['payment_status']??''));
  $paymentId=(string)($payment['cf_payment_id']??'');$method=(string)($payment['payment_group']??'');
  if($orderId!==''&&$providerStatus==='SUCCESS'){
   $updated=link_gateway_mark_paid('cashfree',$orderId,$paymentId,$method,isset($payment['payment_amount'])?(float)$payment['payment_amount']:null,(string)($payment['payment_currency']??'INR'));
  }elseif($orderId!==''&&$providerStatus==='REFUNDED'){
   $updated=link_gateway_mark_refunded('cashfree',$orderId,$paymentId);
  }elseif($orderId!==''&&in_array($providerStatus,['FAILED','USER_DROPPED','PENDING'],true)){
   $mapped=['FAILED'=>'failed','USER_DROPPED'=>'cancelled','PENDING'=>'pending'][$providerStatus];
   $updated=link_gateway_update_status('cashfree',$orderId,$mapped,$paymentId,$method);
  }
 }
 $pdo->commit();
}catch(PDOException $e){
 if($pdo->inTransaction())$pdo->rollBack();
 if($e->getCode()==='23000'){http_response_code(200);exit('Duplicate event.');}
 error_log('LINK webhook database processing failed: '.$e->getMessage());http_response_code(500);exit('Temporary processing failure. Retry delivery.');
}catch(Throwable $e){
 if($pdo->inTransaction())$pdo->rollBack();
 error_log('LINK webhook processing failed: '.$e->getMessage());http_response_code(500);exit('Temporary processing failure. Retry delivery.');
}
http_response_code(200);
echo $updated?'Processed':'Accepted';
