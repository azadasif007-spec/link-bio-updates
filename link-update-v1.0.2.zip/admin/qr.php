<?php
declare(strict_types=1);
require_once dirname(__DIR__) . '/app/bootstrap.php';
require_once dirname(__DIR__) . '/app/activity.php';
if(!link_app_installed()){header('Location: ../install/');exit;}
if(empty($_SESSION['link_admin_id'])){header('Location: index.php');exit;}
// Backward-compatible schema upgrade for installations created before QR styling.
$qrColumns=link_db()->query('SHOW COLUMNS FROM qr_codes')->fetchAll(PDO::FETCH_COLUMN);
if(!in_array('color_dark',$qrColumns,true)) link_db()->exec("ALTER TABLE qr_codes ADD color_dark CHAR(6) NOT NULL DEFAULT '17362b'");
if(!in_array('color_light',$qrColumns,true)) link_db()->exec("ALTER TABLE qr_codes ADD color_light CHAR(6) NOT NULL DEFAULT 'ffffff'");
$error='';$success='';
function valid_destination(string $url): bool {
    return filter_var($url,FILTER_VALIDATE_URL) && in_array(strtolower((string)parse_url($url,PHP_URL_SCHEME)),['http','https'],true);
}
function valid_qr_color(string $value,string $fallback): string { return preg_match('/^[0-9a-fA-F]{6}$/',$value) ? strtolower($value) : $fallback; }
if($_SERVER['REQUEST_METHOD']==='POST'){
    link_verify_csrf();
    $action=(string)($_POST['action']??'');
    if($action==='create'){
        $name=substr(trim((string)($_POST['name']??'')),0,120);
        $url=trim((string)($_POST['destination_url']??''));
        $dark=valid_qr_color((string)($_POST['color_dark']??''),'17362b');
        $light=valid_qr_color((string)($_POST['color_light']??''),'ffffff');
        if($name==='' || !valid_destination($url)) $error='Enter a QR name and a valid http or https destination.';
        else{
            $code=bin2hex(random_bytes(10));
            $q=link_db()->prepare('INSERT INTO qr_codes (code,name,destination_url,color_dark,color_light) VALUES (?,?,?,?,?)');
            $q->execute([$code,$name,$url,$dark,$light]);link_activity_log('qr_created',$name);$success='Your new dynamic QR code is ready.';
        }
    }elseif($action==='update'){
        $id=(int)($_POST['id']??0);$name=substr(trim((string)($_POST['name']??'')),0,120);$url=trim((string)($_POST['destination_url']??''));
        $dark=valid_qr_color((string)($_POST['color_dark']??''),'17362b');
        $light=valid_qr_color((string)($_POST['color_light']??''),'ffffff');
        if($id<1 || $name==='' || !valid_destination($url)) $error='Please enter a valid name and destination URL.';
        else{$q=link_db()->prepare('UPDATE qr_codes SET name=?,destination_url=?,color_dark=?,color_light=? WHERE id=?');$q->execute([$name,$url,$dark,$light,$id]);link_activity_log('qr_updated','QR #'.$id.' · '.$name);$success='QR settings updated. Existing printed QR codes will continue to work.';}
    }elseif($action==='toggle'){
        $id=(int)($_POST['id']??0);$q=link_db()->prepare('UPDATE qr_codes SET is_active=1-is_active WHERE id=?');$q->execute([$id]);link_activity_log('qr_status_changed','QR #'.$id);$success='QR status updated.';
    }
}
$codes=link_db()->query('SELECT * FROM qr_codes ORDER BY created_at DESC,id DESC')->fetchAll();
$host=preg_replace('/[^a-zA-Z0-9.:-]/','',(string)($_SERVER['HTTP_HOST']??''));
$baseUrl='https://'.$host;
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>QR Manager · LINK</title><link rel="stylesheet" href="../assets/css/admin.css"></head><body class="dashboard-body"><aside class="sidebar"><div class="side-brand">L<span>·</span> LINK</div><div class="side-label">WORKSPACE</div><a class="side-link" href="index.php">◈ &nbsp; Profile editor</a><a class="side-link active" href="qr.php">▦ &nbsp; QR manager</a><a class="side-link" href="payments.php">₹ &nbsp; Payments</a><a class="side-link" href="analytics.php">◷ &nbsp; Analytics</a><a class="side-link" href="security.php">⌑ &nbsp; Security</a><a class="side-link" href="backups.php">↓ &nbsp; Backups</a><a class="side-link" href="activity.php">◷ &nbsp; Activity log</a><a class="side-link" href="updates.php">↻ &nbsp; Software updates</a><a class="side-link" href="../" target="_blank" rel="noopener">↗ &nbsp; View live page</a><div class="side-bottom"><span><?=link_e((string)($_SESSION['link_admin_email']??''))?></span><a href="logout.php">Sign out ↗</a></div></aside><main class="dash-main"><header class="dash-header"><div><p class="eyebrow">SMART DESTINATIONS</p><h1>QR manager</h1><p class="muted">Create a permanent QR code and update where it leads whenever you need.</p></div></header><?php if($success):?><div class="notice success"><?=link_e($success)?></div><?php endif;?><?php if($error):?><div class="notice error"><?=link_e($error)?></div><?php endif;?><section class="editor-card"><div class="section-head"><div><p class="eyebrow">NEW QR CODE</p><h2>Create a destination</h2><p class="muted">Your QR points to your own domain, so the destination can be changed later.</p></div></div><form method="post" class="qr-create"><input type="hidden" name="_csrf" value="<?=link_e(link_csrf_token())?>"><input type="hidden" name="action" value="create"><div class="form-grid"><label>QR name<input name="name" maxlength="120" placeholder="e.g. Business card" required></label><label>Destination URL<input type="url" name="destination_url" placeholder="https://example.com" required></label><label>QR colour<input type="color" name="color_dark" value="#17362b"></label><label>Background colour<input type="color" name="color_light" value="#ffffff"></label></div><button class="primary-btn" type="submit">Create QR code <span>→</span></button></form></section><section class="editor-card"><div class="section-head"><div><p class="eyebrow">YOUR QR LIBRARY</p><h2>Created QR codes</h2><p class="muted"><?=count($codes)?> total QR code<?=count($codes)===1?'':'s'?></p></div></div><?php if(!$codes):?><p class="muted">No QR codes yet. Create your first one above.</p><?php else:?><div class="qr-grid"><?php foreach($codes as $qr):$short=$baseUrl.'/r/'.$qr['code'];?><article class="qr-card"><div class="qr-image"><img loading="lazy" alt="QR code for <?=link_e($qr['name'])?>" src="https://api.qrserver.com/v1/create-qr-code/?size=220x220&amp;format=png&amp;color=<?=link_e($qr['color_dark']??'17362b')?>&amp;bgcolor=<?=link_e($qr['color_light']??'ffffff')?>&amp;data=<?=rawurlencode($short)?>"></div><div class="qr-details"><div class="qr-title-row"><strong><?=link_e($qr['name'])?></strong><span class="status-pill <?=$qr['is_active']?'on':'off'?>"><?=$qr['is_active']?'Active':'Paused'?></span></div><p class="qr-destination"><?=link_e($qr['destination_url'])?></p><p class="qr-count"><?=number_format((int)$qr['scans'])?> scans · Created <?=link_e(date('d M Y',strtotime($qr['created_at'])))?></p><form method="post" class="qr-edit"><input type="hidden" name="_csrf" value="<?=link_e(link_csrf_token())?>"><input type="hidden" name="action" value="update"><input type="hidden" name="id" value="<?=(int)$qr['id']?>"><label>QR name<input name="name" value="<?=link_e($qr['name'])?>" maxlength="120" required></label><label>Destination<input name="destination_url" type="url" value="<?=link_e($qr['destination_url'])?>" required></label><div class="form-grid qr-colours"><label>QR colour<input type="color" name="color_dark" value="#<?=link_e($qr['color_dark']??'17362b')?>"></label><label>Background<input type="color" name="color_light" value="#<?=link_e($qr['color_light']??'ffffff')?>"></label></div><button class="outline-btn" type="submit">Save QR settings</button></form><div class="qr-actions"><button class="outline-btn copy-qr" type="button" data-url="<?=link_e($short)?>">Copy QR link</button><a class="outline-btn" href="https://api.qrserver.com/v1/create-qr-code/?size=900x900&amp;format=png&amp;color=<?=link_e($qr['color_dark']??'17362b')?>&amp;bgcolor=<?=link_e($qr['color_light']??'ffffff')?>&amp;data=<?=rawurlencode($short)?>" target="_blank" rel="noopener">Download PNG</a><a class="outline-btn" href="https://api.qrserver.com/v1/create-qr-code/?size=1200x1200&amp;format=svg&amp;color=<?=link_e($qr['color_dark']??'17362b')?>&amp;bgcolor=<?=link_e($qr['color_light']??'ffffff')?>&amp;data=<?=rawurlencode($short)?>" target="_blank" rel="noopener">Download SVG</a><form method="post"><input type="hidden" name="_csrf" value="<?=link_e(link_csrf_token())?>"><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?=(int)$qr['id']?>"><button class="outline-btn" type="submit"><?=$qr['is_active']?'Pause':'Activate'?></button></form></div></div></article><?php endforeach;?></div><?php endif;?></section></main><script>
document.addEventListener('click',async function(e){const b=e.target.closest('.copy-qr');if(!b)return;try{await navigator.clipboard.writeText(b.dataset.url);const old=b.textContent;b.textContent='Copied!';setTimeout(()=>b.textContent=old,1400)}catch(_){window.prompt('Copy this QR link',b.dataset.url)}});
</script></body></html>
