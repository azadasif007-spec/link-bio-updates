<?php
declare(strict_types=1);
require_once dirname(__DIR__) . '/app/bootstrap.php';
require_once dirname(__DIR__) . '/app/security.php';
require_once dirname(__DIR__) . '/app/activity.php';
if (!link_app_installed()) { header('Location: ../install/'); exit; }
$error=''; $success='';
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['login'])) {
 link_verify_csrf(); $email=trim((string)($_POST['email']??'')); $password=(string)($_POST['password']??'');
 if(link_security_locked($email)) $error='Too many sign-in attempts. Please wait 15 minutes before trying again.';
 else { $stmt=link_db()->prepare('SELECT id,email,password_hash FROM admins WHERE email=? LIMIT 1');$stmt->execute([$email]);$admin=$stmt->fetch();
  if($admin&&password_verify($password,$admin['password_hash'])) { link_security_clear_failures($email);$sec=link_security_row((int)$admin['id']);
   if(!empty($sec['totp_enabled'])&&!empty($sec['totp_secret_enc'])) {session_regenerate_id(true);$_SESSION['link_pending_admin_id']=(int)$admin['id'];$_SESSION['link_pending_admin_email']=$admin['email'];}
   else {session_regenerate_id(true);$_SESSION['link_admin_id']=(int)$admin['id'];$_SESSION['link_admin_email']=$admin['email'];link_activity_log('admin_login','Password sign-in successful');header('Location: index.php');exit;}
  } else {link_security_record_failure($email);usleep(350000);$error='The email or password is incorrect.';}
 }
}
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['verify_totp'])) {
 link_verify_csrf();$pending=(int)($_SESSION['link_pending_admin_id']??0);$pendingEmail=(string)($_SESSION['link_pending_admin_email']??'');
 $sec=$pending?link_security_row($pending):[];$secret=!empty($sec['totp_secret_enc'])?link_security_decrypt($sec['totp_secret_enc']):'';$submitted=trim((string)($_POST['totp_code']??''));$locked=$pendingEmail!==''&&link_security_locked($pendingEmail);$validTotp=$secret!==''&&link_totp_verify($secret,$submitted);$validRecovery=!$locked&&!$validTotp&&$pending?link_security_consume_recovery_code($pending,$submitted):false;
 if(!$locked&&$pending&&!empty($sec['totp_enabled'])&&($validTotp||$validRecovery)) {
  session_regenerate_id(true);$_SESSION['link_admin_id']=$pending;$_SESSION['link_admin_email']=(string)($_SESSION['link_pending_admin_email']??'');
  unset($_SESSION['link_pending_admin_id'],$_SESSION['link_pending_admin_email']);link_activity_log('admin_login',$validRecovery?'Password and one-time recovery code sign-in':'Password and authenticator sign-in');header('Location: index.php');exit;
 } else {if($pendingEmail!=='')link_security_record_failure($pendingEmail);$error=$locked?'Too many verification attempts. Please wait 15 minutes.':'The authenticator code is incorrect or expired.';}
}
if(empty($_SESSION['link_admin_id'])):
if(!empty($_SESSION['link_pending_admin_id'])):
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Verify sign-in · LINK</title><link rel="stylesheet" href="../assets/css/admin.css"></head><body class="admin-body"><main class="login-wrap"><div class="setup-brand">L<span>·</span> LINK</div><section class="login-card"><p class="eyebrow">TWO-FACTOR SECURITY</p><h1>Verify it’s you.</h1><p class="muted">Enter your six-digit authenticator code or a one-time recovery code.</p><?php if($error):?><div class="notice error"><?=link_e($error)?></div><?php endif;?><form method="post"><input type="hidden" name="_csrf" value="<?=link_e(link_csrf_token())?>"><input type="hidden" name="verify_totp" value="1"><label>Authenticator code<input name="totp_code" inputmode="numeric" maxlength="16" autocomplete="one-time-code" placeholder="123456 or ABCD-EF12" required autofocus></label><button class="primary-btn" type="submit">Verify and sign in <span>→</span></button></form><a class="back-link" href="logout.php">Cancel sign-in</a></section></main></body></html><?php exit; endif;
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Admin Login · LINK</title><link rel="stylesheet" href="../assets/css/admin.css"></head><body class="admin-body"><main class="login-wrap"><div class="setup-brand">L<span>·</span> LINK</div><section class="login-card"><p class="eyebrow">YOUR CONTROL ROOM</p><h1>Welcome back.</h1><p class="muted">Sign in to manage your digital identity.</p><?php if($error):?><div class="notice error"><?=link_e($error)?></div><?php endif;?><form method="post"><input type="hidden" name="_csrf" value="<?=link_e(link_csrf_token())?>"><input type="hidden" name="login" value="1"><label>Email address<input type="email" name="email" autocomplete="username" required></label><label>Password<input type="password" name="password" autocomplete="current-password" required></label><button class="primary-btn" type="submit">Sign in <span>→</span></button></form><a class="back-link" href="../">← View public page</a></section></main></body></html><?php exit; endif;

if($_SERVER['REQUEST_METHOD']==='POST' && (isset($_POST['upload_avatar']) || isset($_POST['remove_avatar']))) {
    link_verify_csrf();
    $currentAvatar=link_setting('avatar','assets/images/avatar-placeholder.svg');
    $uploadDir=dirname(__DIR__).'/uploads/profiles';
    if(isset($_POST['remove_avatar'])) {
        link_save_setting('avatar','assets/images/avatar-placeholder.svg');
        if(str_starts_with($currentAvatar,'uploads/profiles/')) {
            $oldPath=dirname(__DIR__).'/'. $currentAvatar;
            if(is_file($oldPath) && realpath(dirname($oldPath))===realpath($uploadDir)) @unlink($oldPath);
        }
        link_activity_log('profile_image_removed','Profile image removed');$success='Profile image removed.';
    } else {
        $file=$_FILES['profile_image']??null;
        if(!$file || !isset($file['error']) || $file['error']!==UPLOAD_ERR_OK) {
            $error='Please choose an image file to upload.';
        } elseif((int)$file['size']>5*1024*1024) {
            $error='Image must be 5 MB or smaller.';
        } else {
            $tmp=(string)$file['tmp_name'];
            $info=@getimagesize($tmp);
            $finfo=new finfo(FILEINFO_MIME_TYPE);
            $mime=$finfo->file($tmp);
            $allowed=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
            if(!$info || !isset($allowed[$mime]) || (int)$info[0]>5000 || (int)$info[1]>5000) {
                $error='Use a valid JPG, PNG or WebP image up to 5000 × 5000 pixels.';
            } else {
                if(!is_dir($uploadDir) && !mkdir($uploadDir,0755,true) && !is_dir($uploadDir)) {
                    $error='Upload folder could not be created. Please contact your hosting administrator.';
                } else {
                    $filename=bin2hex(random_bytes(16)).'.'.$allowed[$mime];
                    $destination=$uploadDir.'/'.$filename;
                    if(move_uploaded_file($tmp,$destination)) {
                        link_save_setting('avatar','uploads/profiles/'.$filename);
                        if(str_starts_with($currentAvatar,'uploads/profiles/')) {
                            $oldPath=dirname(__DIR__).'/'.$currentAvatar;
                            if(is_file($oldPath) && realpath(dirname($oldPath))===realpath($uploadDir)) @unlink($oldPath);
                        }
                        link_activity_log('profile_image_uploaded','Profile image replaced');$success='Profile image uploaded successfully.';
                    } else {
                        $error='The image could not be saved. Please try again.';
                    }
                }
            }
        }
    }
}
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['save_profile'])) {
    link_verify_csrf();
    $fields=['name'=>120,'eyebrow'=>120,'headline'=>180,'bio'=>1000,'location'=>160,'avatar'=>500,'accent'=>7,'theme'=>20,'header_mark'=>24,'header_label'=>80,'footer_credit'=>100,'footer_credit_url'=>500,'font_heading'=>30,'font_body'=>30,'button_style'=>20,'avatar_shape'=>20,'profile_layout'=>20,'background_style'=>20,'social_instagram'=>500,'social_facebook'=>500,'social_linkedin'=>500,'social_x'=>500,'social_youtube'=>500,'social_tiktok'=>500,'social_whatsapp'=>80,'social_telegram'=>500];
    foreach($fields as $key=>$max) {
        $value=trim((string)($_POST[$key]??''));
        if(strlen($value)>$max) $value=substr($value,0,$max);
        if($key==='accent' && !preg_match('/^#[0-9a-fA-F]{6}$/',$value)) $value='#c5a46d';
        if($key==='theme' && !in_array($value,['forest','midnight','light','ocean','royal','rose','sunset','slate'],true)) $value='forest';
        if($key==='font_heading' && !in_array($value,['playfair','dm-sans','manrope','poppins','montserrat'],true)) $value='playfair';
        if($key==='font_body' && !in_array($value,['dm-sans','manrope','poppins','montserrat','lato'],true)) $value='dm-sans';
        if($key==='button_style' && !in_array($value,['glass','solid','outline'],true)) $value='glass';
        if($key==='avatar_shape' && !in_array($value,['circle','rounded','square'],true)) $value='circle';
        if($key==='profile_layout' && !in_array($value,['classic','compact','editorial'],true)) $value='classic';
        if($key==='background_style' && !in_array($value,['ambient','plain','glow'],true)) $value='ambient';
        link_save_setting($key,$value);
    }
    $ids=$_POST['link_id']??[]; $labels=$_POST['link_label']??[]; $urls=$_POST['link_url']??[]; $descs=$_POST['link_description']??[]; $active=$_POST['link_active']??[];
    $pdo=link_db(); $pdo->beginTransaction();
    try {
        $seen=[];
        foreach($labels as $i=>$label) {
            $label=trim((string)$label); $url=trim((string)($urls[$i]??''));
            if($label==='' && $url==='') continue;
            if($label==='' || !filter_var($url,FILTER_VALIDATE_URL) || !in_array(strtolower((string)parse_url($url,PHP_URL_SCHEME)),['http','https'],true)) continue;
            $id=(int)($ids[$i]??0); $desc=substr(trim((string)($descs[$i]??'')),0,255); $enabled=isset($active[$i])?1:0;
            if($id>0) { $q=$pdo->prepare('UPDATE links SET label=?,url=?,description=?,sort_order=?,is_active=? WHERE id=?'); $q->execute([substr($label,0,120),$url,$desc,$i,$enabled,$id]); $seen[]=$id; }
            else { $q=$pdo->prepare('INSERT INTO links (label,url,description,sort_order,is_active) VALUES (?,?,?,?,?)'); $q->execute([substr($label,0,120),$url,$desc,$i,$enabled]); $seen[]=(int)$pdo->lastInsertId(); }
        }
        $existing=$pdo->query('SELECT id FROM links')->fetchAll(PDO::FETCH_COLUMN);
        $remove=array_diff(array_map('intval',$existing),$seen);
        if($remove){$in=implode(',',array_fill(0,count($remove),'?'));$q=$pdo->prepare("DELETE FROM links WHERE id IN ($in)");$q->execute(array_values($remove));}
        $pdo->commit(); link_activity_log('profile_updated','Profile details, design, social links and destinations saved');$success='Your profile and links have been saved.';
    } catch(Throwable $e) { $pdo->rollBack(); $error='Could not save changes. Please try again.'; }
}
$settings=[]; foreach(['name','eyebrow','headline','bio','location','avatar','accent','theme','header_mark','header_label','footer_credit','footer_credit_url','font_heading','font_body','button_style','avatar_shape','profile_layout','background_style','social_instagram','social_facebook','social_linkedin','social_x','social_youtube','social_tiktok','social_whatsapp','social_telegram'] as $key) $settings[$key]=link_setting($key,(['accent'=>'#c5a46d','theme'=>'forest','avatar'=>'assets/images/avatar-placeholder.svg','header_mark'=>'L','header_label'=>'MY DIGITAL SPACE','footer_credit'=>'POWERED BY LINK','footer_credit_url'=>'https://link.uikgroup.com','font_heading'=>'playfair','font_body'=>'dm-sans','button_style'=>'glass','avatar_shape'=>'circle','profile_layout'=>'classic','background_style'=>'ambient'][$key]??''));
$links=link_db()->query('SELECT * FROM links ORDER BY sort_order,id')->fetchAll();
$avatarSetting=link_setting('avatar','assets/images/avatar-placeholder.svg');
$avatarPreview=(filter_var($avatarSetting,FILTER_VALIDATE_URL) && in_array(strtolower((string)parse_url($avatarSetting,PHP_URL_SCHEME)),['http','https'],true)) ? $avatarSetting : '../'.ltrim($avatarSetting,'/');
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Dashboard · LINK</title><link rel="stylesheet" href="../assets/css/admin.css"></head><body class="dashboard-body"><aside class="sidebar"><div class="side-brand">L<span>·</span> LINK</div><div class="side-label">WORKSPACE</div><a class="side-link active" href="index.php">◈ &nbsp; Profile editor</a><a class="side-link" href="qr.php">▦ &nbsp; QR manager</a><a class="side-link" href="payments.php">₹ &nbsp; Payments</a><a class="side-link" href="analytics.php">◷ &nbsp; Analytics</a><a class="side-link" href="security.php">⌑ &nbsp; Security</a><a class="side-link" href="backups.php">↓ &nbsp; Backups</a><a class="side-link" href="activity.php">◷ &nbsp; Activity log</a><a class="side-link" href="updates.php">↻ &nbsp; Software updates</a><a class="side-link" href="../" target="_blank">↗ &nbsp; View live page</a><div class="side-bottom"><span><?=link_e((string)($_SESSION['link_admin_email']??''))?></span><a href="logout.php">Sign out ↗</a></div></aside><main class="dash-main"><header class="dash-header"><div><p class="eyebrow">YOUR DIGITAL IDENTITY</p><h1>Profile editor</h1><p class="muted">Make your first impression count.</p></div><a class="preview-btn" href="../" target="_blank">Preview page ↗</a></header><?php if($success):?><div class="notice success"><?=link_e($success)?></div><?php endif;?><?php if($error):?><div class="notice error"><?=link_e($error)?></div><?php endif;?><section class="editor-card image-upload-card"><div class="section-head"><div><p class="eyebrow">PROFILE PHOTO</p><h2>Profile image</h2><p class="muted">Upload a JPG, PNG or WebP image. Maximum 5 MB.</p></div></div><div class="image-upload-layout"><img class="image-upload-preview" src="<?=link_e($avatarPreview)?>" alt="Current profile image" onerror="this.src='../assets/images/avatar-placeholder.svg'"><form method="post" enctype="multipart/form-data" class="image-upload-form"><input type="hidden" name="_csrf" value="<?=link_e(link_csrf_token())?>"><label>Choose image<input type="file" name="profile_image" accept="image/jpeg,image/png,image/webp" required></label><button class="primary-btn" type="submit" name="upload_avatar" value="1">Upload image <span>↑</span></button></form><?php if(str_starts_with(link_setting('avatar',''),'uploads/profiles/')):?><form method="post" onsubmit="return confirm('Remove the uploaded profile image?')"><input type="hidden" name="_csrf" value="<?=link_e(link_csrf_token())?>"><button class="outline-btn" type="submit" name="remove_avatar" value="1">Remove image</button></form><?php endif;?></div></section><form method="post" id="profile-form"><input type="hidden" name="_csrf" value="<?=link_e(link_csrf_token())?>"><section class="editor-card"><div class="section-head"><div><p class="eyebrow">01 / PROFILE</p><h2>Introduce yourself</h2></div></div><div class="form-grid"><label>Display name<input name="name" maxlength="120" value="<?=link_e($settings['name'])?>" required></label><label>Small heading<input name="eyebrow" maxlength="120" value="<?=link_e($settings['eyebrow'])?>"></label><label class="full">Headline<input name="headline" maxlength="180" value="<?=link_e($settings['headline'])?>"></label><label class="full">Short bio<textarea name="bio" rows="3" maxlength="1000"><?=link_e($settings['bio'])?></textarea></label><label>Location<input name="location" value="<?=link_e($settings['location'])?>"></label><label>Profile image URL<input name="avatar" value="<?=link_e($settings['avatar'])?>" placeholder="assets/images/your-photo.jpg"></label><label>Accent colour<input type="color" name="accent" value="<?=link_e($settings['accent'])?>"></label><label>Page theme<select name="theme"><?php foreach(['forest'=>'Forest green','midnight'=>'Midnight navy','light'=>'Ivory light','ocean'=>'Ocean blue','royal'=>'Royal plum','rose'=>'Rose quartz','sunset'=>'Sunset amber','slate'=>'Slate monochrome'] as $v=>$label):?><option value="<?=$v?>" <?=$settings['theme']===$v?'selected':''?>><?=$label?></option><?php endforeach;?></select></label></div></section><section class="editor-card"><div class="section-head"><div><p class="eyebrow">02 / BRANDING</p><h2>Header & footer branding</h2><p class="muted">Customise the small identity line at the top and the attribution at the bottom.</p></div></div><div class="form-grid"><label>Header monogram<input name="header_mark" maxlength="24" value="<?=link_e($settings['header_mark'])?>" placeholder="e.g. UiK"></label><label>Header label<input name="header_label" maxlength="80" value="<?=link_e($settings['header_label'])?>" placeholder="e.g. OFFICIAL DIGITAL PROFILE"></label><label>Footer credit text<input name="footer_credit" maxlength="100" value="<?=link_e($settings['footer_credit'])?>" placeholder="e.g. DESIGNED BY ASIF"></label><label>Footer credit hyperlink<input name="footer_credit_url" type="url" maxlength="500" value="<?=link_e($settings['footer_credit_url'])?>" placeholder="https://example.com"></label></div></section><section class="editor-card"><div class="section-head"><div><p class="eyebrow">03 / DESIGN STUDIO</p><h2>Make it yours</h2><p class="muted">Fine-tune the look of your public profile. Your changes apply instantly after saving.</p></div></div><div class="form-grid">
<label>Heading font<select name="font_heading"><?php foreach(['playfair'=>'Playfair Display','dm-sans'=>'DM Sans','manrope'=>'Manrope','poppins'=>'Poppins','montserrat'=>'Montserrat'] as $v=>$label):?><option value="<?=$v?>" <?=$settings['font_heading']===$v?'selected':''?>><?=$label?></option><?php endforeach;?></select></label>
<label>Body font<select name="font_body"><?php foreach(['dm-sans'=>'DM Sans','manrope'=>'Manrope','poppins'=>'Poppins','montserrat'=>'Montserrat','lato'=>'Lato'] as $v=>$label):?><option value="<?=$v?>" <?=$settings['font_body']===$v?'selected':''?>><?=$label?></option><?php endforeach;?></select></label>
<label>Link button style<select name="button_style"><?php foreach(['glass'=>'Glass / translucent','solid'=>'Solid accent','outline'=>'Minimal outline'] as $v=>$label):?><option value="<?=$v?>" <?=$settings['button_style']===$v?'selected':''?>><?=$label?></option><?php endforeach;?></select></label>
<label>Profile photo shape<select name="avatar_shape"><?php foreach(['circle'=>'Circle','rounded'=>'Rounded square','square'=>'Square'] as $v=>$label):?><option value="<?=$v?>" <?=$settings['avatar_shape']===$v?'selected':''?>><?=$label?></option><?php endforeach;?></select></label>
<label>Profile layout<select name="profile_layout"><?php foreach(['classic'=>'Classic centered','compact'=>'Compact','editorial'=>'Editorial'] as $v=>$label):?><option value="<?=$v?>" <?=$settings['profile_layout']===$v?'selected':''?>><?=$label?></option><?php endforeach;?></select></label>
<label>Background effect<select name="background_style"><?php foreach(['ambient'=>'Ambient gradients','plain'=>'Clean plain','glow'=>'Soft accent glow'] as $v=>$label):?><option value="<?=$v?>" <?=$settings['background_style']===$v?'selected':''?>><?=$label?></option><?php endforeach;?></select></label>
</div><p class="design-hint">Tip: pair a strong accent colour with a readable font and keep the profile photo consistent with your brand.</p></section>
<section class="editor-card"><div class="section-head"><div><p class="eyebrow">04 / SOCIAL PRESENCE</p><h2>Connect your socials</h2><p class="muted">Add your official social profiles. Only filled-in fields appear on your public page.</p></div></div><div class="form-grid">
<label>Instagram profile URL<input type="url" name="social_instagram" value="<?=link_e($settings['social_instagram'])?>" placeholder="https://instagram.com/username"></label>
<label>Facebook page URL<input type="url" name="social_facebook" value="<?=link_e($settings['social_facebook'])?>" placeholder="https://facebook.com/yourpage"></label>
<label>LinkedIn profile URL<input type="url" name="social_linkedin" value="<?=link_e($settings['social_linkedin'])?>" placeholder="https://linkedin.com/in/username"></label>
<label>X profile URL<input type="url" name="social_x" value="<?=link_e($settings['social_x'])?>" placeholder="https://x.com/username"></label>
<label>YouTube channel URL<input type="url" name="social_youtube" value="<?=link_e($settings['social_youtube'])?>" placeholder="https://youtube.com/@channel"></label>
<label>TikTok profile URL<input type="url" name="social_tiktok" value="<?=link_e($settings['social_tiktok'])?>" placeholder="https://tiktok.com/@username"></label>
<label>WhatsApp number<input type="tel" name="social_whatsapp" value="<?=link_e($settings['social_whatsapp'])?>" placeholder="91XXXXXXXXXX"></label>
<label>Telegram profile URL<input type="url" name="social_telegram" value="<?=link_e($settings['social_telegram'])?>" placeholder="https://t.me/username"></label>
</div><p class="design-hint">Use full HTTPS URLs for social profiles. For WhatsApp, enter the country code followed by the number, without + or spaces.</p></section>
<section class="editor-card"><div class="section-head"><div><p class="eyebrow">05 / DESTINATIONS</p><h2>Your important links</h2><p class="muted">Add, edit, reorder or hide links on your page.</p></div><button class="outline-btn" type="button" id="add-link">+ Add link</button></div><div id="link-list"><?php foreach($links as $rowIndex=>$link):?><div class="link-row"><input type="hidden" name="link_id[]" value="<?=(int)$link['id']?>"><label>Title<input name="link_label[]" value="<?=link_e($link['label'])?>" maxlength="120" required></label><label>Destination URL<input name="link_url[]" value="<?=link_e($link['url'])?>" type="url" required></label><label>Description<input name="link_description[]" value="<?=link_e($link['description'])?>" maxlength="255"></label><label class="toggle-label"><input type="checkbox" name="link_active[<?=$rowIndex?>]" value="1" <?=$link['is_active']?'checked':''?>> Visible</label><button class="remove-link" type="button" aria-label="Remove link">×</button></div><?php endforeach;?></div><template id="link-template"><div class="link-row"><input type="hidden" name="link_id[]" value="0"><label>Title<input name="link_label[]" maxlength="120" placeholder="e.g. My website" required></label><label>Destination URL<input name="link_url[]" type="url" placeholder="https://example.com" required></label><label>Description<input name="link_description[]" maxlength="255" placeholder="A short description"></label><label class="toggle-label"><input type="checkbox" name="link_active[]" value="1" checked> Visible</label><button class="remove-link" type="button" aria-label="Remove link">×</button></div></template></section><div class="save-bar"><span>Changes are saved to this installation only.</span><button class="primary-btn" type="submit" name="save_profile" value="1">Save changes <span>→</span></button></div></form></main><script src="admin.js" defer></script></body></html>
