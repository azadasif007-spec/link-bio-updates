'use strict';
document.addEventListener('DOMContentLoaded', function () {
  const list = document.getElementById('link-list');
  const template = document.getElementById('link-template');
  function renumber() {
    if (!list) return;
    list.querySelectorAll('.link-row').forEach((row, index) => {
      const checkbox = row.querySelector('input[type="checkbox"]');
      if (checkbox) checkbox.name = 'link_active[' + index + ']';
    });
  }
  document.addEventListener('click', function (event) {
    if (event.target.matches('#add-link')) {
      if (template && list) {
        list.appendChild(template.content.cloneNode(true));
        renumber();
      }
    }
    if (event.target.matches('.remove-link')) {
      const row = event.target.closest('.link-row');
      if (row) row.remove();
      renumber();
    }
  });
  renumber();
});
