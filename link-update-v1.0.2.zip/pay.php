<?php
declare(strict_types=1);
require_once __DIR__.'/app/bootstrap.php';
require_once __DIR__.'/app/payment_gateways.php';
if(!link_app_installed()){http_response_code(503);exit('Payments are not configured.');}
link_gateway_ensure_schema();
$code=trim((string)($_GET['code']??$_POST['code']??''));
if(!preg_match('/^[a-f0-9]{32}$/',$code)){http_response_code(404);exit('Payment link not found.');}
$q=link_db()->prepare('SELECT * FROM payment_links WHERE code=? LIMIT 1');$q->execute([$code]);$payment=$q->fetch();
if(!$payment){http_response_code(404);exit('Payment link not found.');}
$expired=$payment['expires_at']!==null && strtotime((string)$payment['expires_at'])<time();
$upi=link_setting('payments_upi_id','');$payee=link_setting('payments_payee_name',link_setting('name','Merchant'));
$error='';$success=false;
if($_SERVER['REQUEST_METHOD']==='POST'){
    link_verify_csrf();
    if($payment['status']!=='active'||$expired){$error='This payment request is no longer active.';}
    elseif(!link_payment_valid_upi($upi)){$error='The merchant has not configured Direct UPI payments.';}
    else{
        $customer=substr(trim((string)($_POST['customer_name']??'')),0,120);
        $utr=trim((string)($_POST['utr']??''));
        $note=substr(trim((string)($_POST['note']??'')),0,255);
        if($customer===''||!preg_match('/^[A-Za-z0-9 -]{6,100}$/',$utr)) $error='Enter your name and a valid UPI transaction reference (6–100 letters/numbers).';
        else{
            try{
                $ins=link_db()->prepare("INSERT INTO payment_submissions (payment_link_id,customer_name,utr,customer_note) VALUES (?,?,?,?)");
                $ins->execute([(int)$payment['id'],$customer,$utr,$note]);
                $audit=link_db()->prepare("INSERT INTO payment_audit (payment_link_id,action,detail,actor) VALUES (?,'upi_reference_submitted',?, 'customer')");
                $audit->execute([(int)$payment['id'],'Customer submitted UPI reference']);
                $success=true;
            }catch(PDOException $e){$error=$e->getCode()==='23000'?'This transaction reference has already been submitted. Please contact the merchant if you need help.':'We could not submit your reference. Please try again.';}
        }
    }
}
$upiUri=link_payment_valid_upi($upi)?link_payment_uri($upi,$payee,number_format((float)$payment['amount'],2,'.',''),'LINK '.$payment['code']):'';
$qrUrl=$upiUri!==''?'https://api.qrserver.com/v1/create-qr-code/?size=280x280&format=png&data='.rawurlencode($upiUri):'';
$canPay=$payment['status']==='active'&&!$expired&&$upiUri!=='';
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>Payment · <?=link_e($payment['title'])?></title><style>*{box-sizing:border-box}body{margin:0;background:#f3f4ef;color:#17251f;font-family:Arial,sans-serif}.wrap{max-width:520px;margin:42px auto;padding:0 16px}.brand{text-align:center;color:#fff;background:#123126;border-radius:16px 16px 0 0;padding:20px;font:24px Georgia,serif}.card{background:#fff;border:1px solid #e5e8e1;border-radius:0 0 16px 16px;padding:28px;box-shadow:0 15px 40px #10251f0d}.eyebrow{font-size:10px;letter-spacing:2px;color:#a98755;font-weight:bold}.title{font:28px Georgia,serif;margin:8px 0}.muted{color:#6f7d73;font-size:13px;line-height:1.6}.amount{font:36px Georgia,serif;margin:18px 0 4px}.payee{font-size:12px;color:#627066}.qr{display:block;width:220px;height:220px;object-fit:contain;margin:22px auto 12px;border:1px solid #edf0ea;border-radius:12px;padding:8px}.btn{display:block;text-align:center;background:#17362b;color:#fff;padding:15px;border-radius:9px;text-decoration:none;font-weight:bold;font-size:13px;margin:12px 0}.field{display:grid;gap:7px;margin:14px 0;font-size:12px;font-weight:bold;color:#4d5b52}input{width:100%;padding:13px;border:1px solid #dcded7;border-radius:8px;font-size:14px}.notice{padding:12px;border-radius:8px;background:#fff4e5;color:#81551f;font-size:12px;line-height:1.5;margin:14px 0}.success{background:#e9f3eb;color:#2e6840}.fine{font-size:10px;color:#879188;line-height:1.6;text-align:center;margin-top:20px}.divider{border:0;border-top:1px solid #edf0ea;margin:22px 0}button{width:100%;border:0;cursor:pointer}@media(max-width:560px){.wrap{margin:16px auto}.card{padding:22px}}</style></head><body><main class="wrap"><div class="brand">L · LINK PAYMENTS</div><section class="card"><p class="eyebrow">PAYMENT REQUEST</p><h1 class="title"><?=link_e($payment['title'])?></h1><?php if($payment['description']!==''):?><p class="muted"><?=nl2br(link_e($payment['description']))?></p><?php endif;?><div class="amount">₹<?=number_format((float)$payment['amount'],2)?></div><div class="payee">Pay to <?=link_e($payee)?></div>
<?php if($success):?><div class="notice success">Your UPI reference has been submitted to the merchant. This is not a payment confirmation. The merchant will verify the credit in their account.</div>
<?php else:?><?php if($error!==''):?><div class="notice"><?=link_e($error)?></div><?php endif;?>
<?php if($payment['status']!=='active'||$expired):?><div class="notice">This payment request is paused or expired. Please contact the merchant.</div>
<?php elseif(!$canPay):?><div class="notice">The merchant has not configured UPI payments yet. Please contact the merchant.</div>
<?php else:?><img class="qr" src="<?=link_e($qrUrl)?>" alt="UPI payment QR code"><p class="muted" style="text-align:center">Scan with a UPI app, or open a supported UPI app on your phone.</p><a class="btn" href="<?=link_e($upiUri)?>">Open UPI app to pay ₹<?=number_format((float)$payment['amount'],2)?></a><?php if(link_gateway_ready('razorpay')||link_gateway_ready('cashfree')):?><hr class="divider"><h2 style="font:20px Georgia,serif">Pay securely online</h2><p class="muted">Choose an available provider. UPI, cards and other methods depend on your merchant gateway account.</p><?php foreach(['razorpay'=>'Razorpay','cashfree'=>'Cashfree'] as $provider=>$label):if(link_gateway_ready($provider)):?><form method="post" action="gateway-start.php" class="gateway-form"><input type="hidden" name="_csrf" value="<?=link_e(link_csrf_token())?>"><input type="hidden" name="code" value="<?=link_e($code)?>"><input type="hidden" name="provider" value="<?=link_e($provider)?>"><label class="field">Your name<input name="customer_name" maxlength="120" required autocomplete="name"></label><label class="field">Email<input type="email" name="customer_email" maxlength="190" required autocomplete="email"></label><label class="field">Mobile number<input type="tel" name="customer_phone" maxlength="18" required autocomplete="tel" placeholder="+91 9876543210"></label><button class="btn" type="submit">Continue with <?=link_e($label)?></button></form><?php endif;endforeach;?><?php endif;?><hr class="divider"><h2 style="font:20px Georgia,serif">Already paid?</h2><p class="muted">Submit your transaction reference below. The merchant must independently verify the payment before confirming it.</p><form method="post"><input type="hidden" name="_csrf" value="<?=link_e(link_csrf_token())?>"><input type="hidden" name="code" value="<?=link_e($code)?>"><label class="field">Your name<input name="customer_name" maxlength="120" required autocomplete="name"></label><label class="field">UPI transaction reference / UTR<input name="utr" maxlength="100" minlength="6" required autocomplete="off" placeholder="Enter UPI transaction reference"></label><label class="field">Note (optional)<input name="note" maxlength="255" placeholder="Any additional information"></label><button class="btn" type="submit">Submit reference for verification</button></form><?php endif;?><?php endif;?>
<p class="fine">Payments are made directly to the merchant's UPI ID. LINK does not receive, hold or settle funds. A submitted reference is not proof of payment. Verify the actual credit with your bank or UPI merchant account. Privacy: the merchant receives the details you submit here.</p></section></main></body></html>