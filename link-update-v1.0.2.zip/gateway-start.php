<?php
declare(strict_types=1);
require_once __DIR__.'/app/bootstrap.php';
require_once __DIR__.'/app/payment_gateways.php';
if(!link_app_installed()){http_response_code(503);exit('Payments unavailable.');}
link_gateway_ensure_schema();
if($_SERVER['REQUEST_METHOD']!=='POST'){http_response_code(405);exit('Method not allowed.');}
link_verify_csrf();
$code=trim((string)($_POST['code']??''));$provider=(string)($_POST['provider']??'');
if(!preg_match('/^[a-f0-9]{32}$/',$code)||!in_array($provider,['razorpay','cashfree'],true)||!link_gateway_ready($provider)){http_response_code(400);exit('This payment method is not available.');}
$q=link_db()->prepare("SELECT * FROM payment_links WHERE code=? AND status='active' LIMIT 1");$q->execute([$code]);$p=$q->fetch();
if(!$p||($p['expires_at']!==null&&strtotime((string)$p['expires_at'])<time())){http_response_code(404);exit('Payment request is unavailable or expired.');}
$name=substr(trim((string)($_POST['customer_name']??'')),0,120);
$email=trim((string)($_POST['customer_email']??''));$phone=preg_replace('/[^0-9+]/','',(string)($_POST['customer_phone']??''));
if($name===''||!filter_var($email,FILTER_VALIDATE_EMAIL)||!preg_match('/^\+?[0-9]{10,15}$/',$phone)){http_response_code(422);exit('Enter a valid name, email and phone number.');}
$local='lnk'.bin2hex(random_bytes(12));
$pdo=link_db();$ins=$pdo->prepare("INSERT INTO gateway_transactions (payment_link_id,provider,local_order_id,amount,currency,status) VALUES (?,?,?,?,?,'creating')");
$ins->execute([(int)$p['id'],$provider,$local,$p['amount'],$p['currency']]);
try{
    $customer=['name'=>$name,'email'=>$email,'phone'=>$phone];
    if($provider==='razorpay'){
        $res=link_gateway_create_razorpay((int)$p['id'],$p['title'],$p['description'],(float)$p['amount'],$p['currency'],$local,$customer);
        $u=$pdo->prepare("UPDATE gateway_transactions SET provider_order_id=?,checkout_url=?,status='created' WHERE local_order_id=?");
        $u->execute([$res['provider_order_id'],$res['checkout_url'],$local]);
        header('Location: '.$res['checkout_url'],true,303);exit;
    }
    $res=link_gateway_create_cashfree((int)$p['id'],$p['title'],(float)$p['amount'],$p['currency'],$local,$customer);
    $u=$pdo->prepare("UPDATE gateway_transactions SET provider_order_id=?,payment_session_id=?,status='created' WHERE local_order_id=?");
    $u->execute([$local,$res['payment_session_id'],$local]);
    $env=link_gateway_credentials('cashfree')['environment']==='live'?'production':'sandbox';
    ?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Secure checkout</title><script src="https://sdk.cashfree.com/js/v3/cashfree.js"></script></head><body><p>Opening secure Cashfree checkout…</p><script>
    const cashfree=Cashfree({mode:<?=json_encode($env)?>});
    cashfree.checkout({paymentSessionId:<?=json_encode($res['payment_session_id'])?>,redirectTarget:"_self"}).catch(()=>{document.body.innerHTML="Checkout could not be opened. Please return to the payment link and try again.";});
    </script></body></html><?php
}catch(Throwable $e){
    $u=$pdo->prepare("UPDATE gateway_transactions SET status='error' WHERE local_order_id=?");$u->execute([$local]);
    error_log('LINK gateway start error: '.$e->getMessage());
    http_response_code(502);exit('The payment provider could not start checkout. Please try again or contact the merchant.');
}
