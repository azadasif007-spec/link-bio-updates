'use strict';
// Reserved for lightweight interactions and privacy-conscious analytics.
document.documentElement.classList.add('is-ready');
