<?php
declare(strict_types=1);
require_once __DIR__.'/app/bootstrap.php';
require_once __DIR__.'/app/analytics.php';
$id=(int)($_GET['id']??0);
if($id<1){http_response_code(404);exit('Link not found.');}
$q=link_db()->prepare('SELECT id,url,is_active FROM links WHERE id=? LIMIT 1');$q->execute([$id]);$link=$q->fetch();
if(!$link || !(int)$link['is_active']){http_response_code(404);exit('This link is unavailable.');}
$url=(string)$link['url'];
if(!filter_var($url,FILTER_VALIDATE_URL) || !in_array(strtolower((string)parse_url($url,PHP_URL_SCHEME)),['http','https'],true)){http_response_code(410);exit('This link destination is invalid.');}
link_track_event('link_click',(int)$link['id']);
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Referrer-Policy: no-referrer');
header('Location: '.$url,true,302);exit;
