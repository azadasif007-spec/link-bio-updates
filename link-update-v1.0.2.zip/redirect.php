<?php
declare(strict_types=1);
require_once __DIR__ . '/app/bootstrap.php';
require_once __DIR__ . '/app/analytics.php';

$code=trim((string)($_GET['code']??''));
if(!preg_match('/^[a-f0-9]{12,40}$/',$code)){http_response_code(404);exit('QR code not found.');}
$stmt=link_db()->prepare('SELECT id,destination_url,is_active FROM qr_codes WHERE code=? LIMIT 1');
$stmt->execute([$code]);$qr=$stmt->fetch();
if(!$qr || !(int)$qr['is_active']){http_response_code(404);exit('This QR code is unavailable.');}
$url=(string)$qr['destination_url'];
if(!filter_var($url,FILTER_VALIDATE_URL) || !in_array(strtolower((string)parse_url($url,PHP_URL_SCHEME)),['http','https'],true)){http_response_code(410);exit('This QR destination is invalid.');}

try{link_db()->prepare('UPDATE qr_codes SET scans=scans+1 WHERE id=?')->execute([(int)$qr['id']]);}catch(Throwable $e){}
link_track_event('qr_scan',(int)$qr['id']);
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Referrer-Policy: no-referrer');
header('Location: '.$url,true,302);exit;
