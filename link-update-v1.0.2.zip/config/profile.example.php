<?php
/**
 * Example profile configuration.
 * The installer will create config/profile.php for each installation.
 */
return [
    'name' => 'Your Name',
    'eyebrow' => 'WELCOME TO MY DIGITAL SPACE',
    'headline' => 'Everything you need, in one place.',
    'bio' => 'A short introduction about you, your work and what you do.',
    'location' => '',
    'avatar' => 'assets/images/avatar-placeholder.svg',
    'cover' => '',
    'accent' => '#c5a46d',
    'theme' => 'forest',
    'links' => [
        ['label' => 'My Website', 'url' => 'https://example.com', 'icon' => 'globe', 'description' => 'Explore my work', 'enabled' => true],
        ['label' => 'WhatsApp', 'url' => 'https://wa.me/910000000000', 'icon' => 'message-circle', 'description' => 'Let’s connect', 'enabled' => true],
        ['label' => 'Instagram', 'url' => 'https://instagram.com/', 'icon' => 'instagram', 'description' => 'Follow along', 'enabled' => true],
        ['label' => 'LinkedIn', 'url' => 'https://linkedin.com/', 'icon' => 'linkedin', 'description' => 'Professional profile', 'enabled' => true],
    ],
    'socials' => [],
];
