<?php
declare(strict_types=1);
require_once __DIR__.'/app/bootstrap.php';
require_once __DIR__.'/app/payment_gateways.php';
require_once __DIR__.'/app/activity.php';
if(!link_app_installed()){http_response_code(404);exit;}
$expected=link_setting('backup_cron_token_hash','');
$provided=(string)($_GET['key']??'');
if($expected===''||$provided===''||!hash_equals($expected,hash('sha256',$provided))){http_response_code(403);exit('Forbidden');}
link_gateway_ensure_schema();link_activity_ensure_schema();
$tables=['settings','links','qr_codes','analytics_events','payment_links','payment_submissions','payment_audit','gateway_transactions','gateway_webhook_events','admin_activity'];
$data=['format'=>'LINK-FULL-BACKUP-2','created_at'=>gmdate('c'),'notice'=>'Automated private backup. Restore only to this same LINK installation.','tables'=>[],'files'=>[],'installation_fingerprint'=>hash('sha256',(string)(require __DIR__.'/config/installation.php')['tracking_secret'])];
foreach($tables as $table)$data['tables'][$table]=link_db()->query('SELECT * FROM `'.$table.'`')->fetchAll();
$profileDir=__DIR__.'/uploads/profiles';
if(is_dir($profileDir))foreach(glob($profileDir.'/*')?:[] as $file){$name=basename($file);if(!is_file($file)||!preg_match('/^[a-f0-9]{32}\.(jpg|png|webp)$/',$name))continue;$bytes=file_get_contents($file);if($bytes!==false&&strlen($bytes)<=5*1024*1024)$data['files']['uploads/profiles/'.$name]=base64_encode($bytes);}
$json=json_encode($data,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES);
if($json===false){http_response_code(500);exit('Backup encoding failed');}
$dir=__DIR__.'/storage/backups';
if(!is_dir($dir)&&!mkdir($dir,0750,true)&&!is_dir($dir)){http_response_code(500);exit('Backup storage unavailable');}
$path=$dir.'/link-auto-'.gmdate('Ymd-His').'.json';
if(file_put_contents($path,$json,LOCK_EX)===false){http_response_code(500);exit('Backup write failed');}
@chmod($path,0640);
$files=glob($dir.'/link-auto-*.json')?:[];usort($files,static fn($a,$b)=>filemtime($b)<=>filemtime($a));
foreach(array_slice($files,14) as $old)@unlink($old);
link_activity_log('automatic_backup_created','Scheduled full backup saved; retention is 14 files');
header('Content-Type: text/plain; charset=utf-8');header('Cache-Control: no-store');echo 'OK: full backup created; retained '.min(count($files),14).' backup files.';
