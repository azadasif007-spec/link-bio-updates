# LINK

**One link. Your entire digital identity.**

LINK is a reusable, self-hosted link-in-bio application for PHP 8.2+ and MySQL/MariaDB hosting, including Hostinger shared hosting. Every deployment has its own profile, admin account and database while sharing this repository.

## Implemented

- Premium responsive public profile
- Database-backed profile settings and links
- First-run installer at `/install/`
- Admin login at `/admin/`
- Profile editor for display name, heading, bio, location, image URL, theme and accent colour
- Profile Design Studio with selectable heading/body fonts, classic/compact/editorial layouts, glass/solid/outline link buttons, avatar shapes and background effects
- Secure profile image upload/removal for JPG, PNG and WebP (5 MB limit), with random filenames and MIME/dimension validation
- Add, remove, hide and edit public links
- Social profile links for Instagram, Facebook, LinkedIn, X, YouTube, TikTok, WhatsApp and Telegram
- Dynamic QR manager with permanent redirect URLs, editable destinations, activation controls, scan totals, custom foreground/background colours and PNG/SVG downloads
- Analytics dashboard for profile views, tracked link clicks, QR scans, daily visitor estimates and device breakdown
- QR scan audit with timestamp, QR name, browser/OS/device, referrer host, masked IP prefix, pseudonymous repeat-source token and automated-traffic/burst indicators
- Public privacy notice describing the technical scan metadata collected
- LINK Payments foundation: fixed-amount payment links, merchant-configured Direct UPI QR/deep links, customer UTR submissions and manual merchant verification
- Payment submission audit trail and pause/activate controls
- Daily pseudonymous visitor hashes; raw IP addresses are not stored
- QR scan source hashes are keyed and pseudonymous; exact IP and precise geolocation are not stored
- Eight distinct profile themes: Forest green, Midnight navy, Ivory light, Ocean blue, Royal plum, Rose quartz, Sunset amber and Slate monochrome
- CSRF protection, password hashing, secure session cookies, 30-minute administrator idle timeout, prepared SQL statements and output escaping
- Administrator login rate limiting (eight failed attempts per 15 minutes per keyed email/network identity)
- Optional authenticator-app two-factor authentication (TOTP) with ten single-use recovery codes
- Administrator activity log for sign-ins, profile edits, QR changes, payment administration, security and backup events
- Full JSON backups including uploaded profile images, installation fingerprint validation and protected same-installation restore
- Token-protected daily scheduled full backups with 14-file retention
- Gateway webhook lifecycle updates for paid, pending, failed, cancelled, expired and refunded transactions
- Security dashboard for enabling and disabling authenticator-based 2FA
- Private JSON backup and restore for profile, links, QR, analytics and payment data
- Transactional, retry-safe gateway webhook processing; failed processing rolls back so providers can retry
- Generic installer error messages with technical details written to the server error log
- HTTPS Strict-Transport-Security response header
- GitHub Actions PHP syntax checks and TOTP security smoke tests
- Apache hardening rules and protected upload/storage folders
- GitHub Actions PHP syntax checks

## Install on Hostinger

1. Create a MySQL database and database user in hPanel; grant the user access to the database.
2. Upload the repository contents to the subdomain document root (for example, `link.uikgroup.com`).
3. In hPanel, select PHP 8.2 or newer and ensure PDO MySQL is enabled.
4. Visit `https://your-subdomain/install/`.
5. Enter the database host, database name, database username and password. Create an admin email and a strong password (at least 12 characters).
6. After setup, sign in at `https://your-subdomain/admin/`.

The installer creates the required tables and writes the database credentials to `config/installation.php`. The config directory is blocked from direct web access by the included Apache rules. Keep a backup of this file and your database.

## Local preview

The application now uses the installer and a MySQL/MariaDB database. Create a database, configure a local PHP server with PDO MySQL enabled, and follow the same steps at `/install/`.

## Security operations\n\nAfter deployment, sign in to Admin → Security and enable authenticator-app two-factor authentication. Save your authenticator account in a secure password manager and keep your device available; After enabling TOTP, save the ten one-time recovery codes shown on screen. Each code works once and is not displayed again. Admin → Activity log records important administrator actions without storing payment secrets. Use Admin → Backups to download full private backups, including uploaded profile images. Full backups are bound to the originating installation and cannot be restored to another LINK installation. Admin accounts, TOTP secrets and the installation configuration are excluded. Generate a daily backup URL in Admin → Backups, then add it once as a daily Hostinger Cron Job; scheduled backups are stored under protected storage and the latest 14 are retained. Treat the generated URL as a password. Restore replaces profile, link, QR, analytics, activity and payment records.\n\nThe login limiter temporarily blocks an email/network identity after eight failures in 15 minutes. It uses a keyed hash rather than storing raw IP addresses. Administrator sessions expire after 30 minutes of inactivity. Webhook handling is transactional and returns a retryable server error when processing fails.\n\n## OTA software updates

Each installed LINK instance includes Admin → Software updates. It checks the public signed distribution channel at `azadasif007-spec/link-bio-updates` and installs checksum-verified code-only packages. The source repository remains private; the public repository contains only versioned update ZIPs and the latest signed manifest. The updater creates a pre-update code archive, protects installation configuration, database, uploads and private storage, and attempts code rollback if installation fails. OTA requires PHP cURL, OpenSSL and ZIP extensions, writable application folders, and outbound HTTPS access to GitHub.

To publish OTA releases, add two GitHub Actions repository secrets to the private source repository:
- `LINK_OTA_SIGNING_KEY`: the PEM private signing key. Never commit it or upload it to a LINK hosting account.
- `LINK_OTA_PUBLISH_TOKEN`: a fine-grained GitHub personal access token with **Contents: Read and write** access to the public `link-bio-updates` repository only. It is used only to publish signed ZIPs and the manifest.

Create a version tag such as `v1.0.3` to trigger publishing. The workflow validates PHP, builds a code-only package, signs its manifest, and pushes the package and manifest to the public distribution repository. To republish an existing tag, use Actions → Publish signed LINK OTA release → Run workflow and enter the tag. Every LINK installation can then check and install the release independently from its own admin panel. Current OTA packages update application files only; database schema changes require a separately designed, versioned migration process and must not be assumed to run automatically.

## Planned next

- Expanded analytics and detailed QR scan history
- Gateway refunds, automated reconciliation tools and extended payment reporting

## Architecture principles

- One codebase, independent installation data
- No SaaS subscription
- No build step or Node.js requirement on shared hosting
- QR destinations can be changed without reprinting codes
- Useful analytics with privacy-conscious data handling


## LINK Payments

The first payment release supports fixed-amount INR payment requests using the installation owner's own UPI ID. Customers can open a UPI app or scan the generated UPI QR, then optionally submit a UPI transaction reference. Submissions remain pending until the merchant independently verifies the credit in their bank/UPI account. A submitted UTR is not proof of payment. LINK does not receive, hold, route or settle funds.

Razorpay and Cashfree adapters are available as optional merchant-owned integrations. Configure test credentials and webhook secrets in Admin → Payments before enabling either provider. Razorpay uses hosted Payment Links and the `payment_link.paid` signed webhook. Cashfree uses server-created Orders, hosted JS checkout, signed webhooks and a server-side order/payment status check on return. Configure webhook URLs displayed in the Payments panel and subscribe to Razorpay `payment_link.paid` and Cashfree payment success events. Switch to live credentials only after successful sandbox testing and merchant account activation. Credentials are encrypted at rest using the installation-specific secret. Never collect or store card numbers, CVV, UPI PINs or OTPs in LINK. Webhook events are authenticated; only successful events with matching amount and currency can mark gateway transactions paid. Signed provider webhooks can update transaction statuses for paid, pending, failed, cancelled, expired and refunded states where the provider supplies the corresponding event. Refund and settlement reconciliation still require review in the merchant provider dashboard; LINK does not initiate refunds automatically.
