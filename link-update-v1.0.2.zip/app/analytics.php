<?php
declare(strict_types=1);

/**
 * Add scan-intelligence fields to older installations without touching existing analytics.
 */
function link_ensure_scan_columns(): void {
    static $checked=false;
    if($checked) return;
    $checked=true;
    try {
        $pdo=link_db();
        $columns=$pdo->query('SHOW COLUMNS FROM analytics_events')->fetchAll(PDO::FETCH_COLUMN);
        $add=[
            'source_hash'=>"ALTER TABLE analytics_events ADD source_hash CHAR(64) DEFAULT NULL",
            'ip_masked'=>"ALTER TABLE analytics_events ADD ip_masked VARCHAR(45) DEFAULT NULL",
            'user_agent'=>"ALTER TABLE analytics_events ADD user_agent VARCHAR(255) DEFAULT NULL",
            'browser'=>"ALTER TABLE analytics_events ADD browser VARCHAR(40) DEFAULT NULL",
            'os_name'=>"ALTER TABLE analytics_events ADD os_name VARCHAR(40) DEFAULT NULL",
            'is_bot'=>"ALTER TABLE analytics_events ADD is_bot TINYINT(1) NOT NULL DEFAULT 0",
            'ip_source'=>"ALTER TABLE analytics_events ADD ip_source VARCHAR(20) DEFAULT NULL"
        ];
        foreach($add as $column=>$sql) if(!in_array($column,$columns,true)) $pdo->exec($sql);
        if(!in_array('idx_source_hash_created',$pdo->query("SHOW INDEX FROM analytics_events")->fetchAll(PDO::FETCH_COLUMN,2),true)) {
            $pdo->exec('CREATE INDEX idx_source_hash_created ON analytics_events (source_hash,created_at)');
        }
    } catch(Throwable $e) {
        // Keep redirects available even if optional analytics schema upgrades are unavailable.
    }
}

function link_ip_in_cidr(string $ip,string $cidr): bool {
    [$network,$bits]=array_pad(explode('/',$cidr,2),2,null);
    $packedIp=@inet_pton($ip);$packedNetwork=@inet_pton((string)$network);
    if($packedIp===false || $packedNetwork===false || strlen($packedIp)!==strlen($packedNetwork)) return false;
    $max=strlen($packedIp)*8;$prefix=$bits===null?$max:(int)$bits;
    if($prefix<0 || $prefix>$max) return false;
    $whole=intdiv($prefix,8);$remaining=$prefix%8;
    if($whole>0 && substr($packedIp,0,$whole)!==substr($packedNetwork,0,$whole)) return false;
    if($remaining>0) {
        $mask=(0xff << (8-$remaining)) & 0xff;
        if((ord($packedIp[$whole]) & $mask)!==(ord($packedNetwork[$whole]) & $mask)) return false;
    }
    return true;
}

/** Cloudflare published proxy ranges. Review against https://www.cloudflare.com/ips/ periodically. */
function link_is_cloudflare_proxy(string $ip): bool {
    static $ranges=[
        '173.245.48.0/20','103.21.244.0/22','103.22.200.0/22','103.31.4.0/22',
        '141.101.64.0/18','108.162.192.0/18','190.93.240.0/20','188.114.96.0/20',
        '197.234.240.0/22','198.41.128.0/17','162.158.0.0/15','104.16.0.0/13',
        '104.24.0.0/14','172.64.0.0/13','131.0.72.0/22',
        '2400:cb00::/32','2606:4700::/32','2803:f800::/32','2405:b500::/32',
        '2405:8100::/32','2a06:98c0::/29','2c0f:f248::/32'
    ];
    foreach($ranges as $range) if(link_ip_in_cidr($ip,$range)) return true;
    return false;
}

/** Trust CF-Connecting-IP only when the immediate peer is in Cloudflare's published ranges. */
function link_client_ip_details(): array {
    $remote=trim((string)($_SERVER['REMOTE_ADDR']??''));
    if(filter_var($remote,FILTER_VALIDATE_IP) && link_is_cloudflare_proxy($remote)) {
        $candidate=trim((string)($_SERVER['HTTP_CF_CONNECTING_IP']??''));
        if(filter_var($candidate,FILTER_VALIDATE_IP,FILTER_FLAG_NO_PRIV_RANGE|FILTER_FLAG_NO_RES_RANGE)) {
            return [$candidate,'cloudflare'];
        }
        return [null,'cloudflare_header_unavailable'];
    }
    if(filter_var($remote,FILTER_VALIDATE_IP,FILTER_FLAG_NO_PRIV_RANGE|FILTER_FLAG_NO_RES_RANGE)) {
        return [$remote,'origin'];
    }
    return [null,'unavailable'];
}

function link_mask_ip(string $ip): ?string {
    if(filter_var($ip,FILTER_VALIDATE_IP,FILTER_FLAG_IPV4)) {
        $parts=explode('.',$ip);$parts[3]='0';return implode('.',$parts).'/24';
    }
    if(filter_var($ip,FILTER_VALIDATE_IP,FILTER_FLAG_IPV6)) {
        $packed=@inet_pton($ip);
        if($packed===false) return null;
        $masked=substr($packed,0,6).str_repeat("\\0",10);
        $result=inet_ntop($masked);
        return $result!==false?$result.'/48':null;
    }
    return null;
}

function link_scan_client_details(string $ua): array {
    $u=strtolower($ua);
    $browser='Other';
    if(str_contains($u,'edg/')) $browser='Edge';
    elseif(str_contains($u,'opr/') || str_contains($u,'opera')) $browser='Opera';
    elseif(str_contains($u,'firefox/')) $browser='Firefox';
    elseif(str_contains($u,'chrome/') && !str_contains($u,'chromium')) $browser='Chrome';
    elseif(str_contains($u,'safari/') && !str_contains($u,'chrome/')) $browser='Safari';
    $os='Other';
    if(str_contains($u,'android')) $os='Android';
    elseif(str_contains($u,'iphone') || str_contains($u,'ipad') || str_contains($u,'ios')) $os='iOS';
    elseif(str_contains($u,'windows')) $os='Windows';
    elseif(str_contains($u,'mac os') || str_contains($u,'macintosh')) $os='macOS';
    elseif(str_contains($u,'linux')) $os='Linux';
    $device=preg_match('/ipad|tablet/',$u)?'tablet':(preg_match('/mobile|android|iphone/',$u)?'mobile':'desktop');
    $bot=(bool)preg_match('/bot|crawler|spider|preview|fetcher|curl|wget|headless|monitoring|uptime|facebookexternalhit|whatsapp|telegrambot|slackbot|discordbot/i',$ua);
    return [$device,$browser,$os,$bot?1:0];
}

function link_track_event(string $type, ?int $targetId = null): void {
    if (!in_array($type, ['page_view','link_click','qr_scan'], true)) return;
    try {
        $cfg=require dirname(__DIR__).'/config/installation.php';
        [$resolvedIp,$ipSource]=link_client_ip_details();
        $ip=(string)($resolvedIp??'');
        $secret=(string)($cfg['tracking_secret']??'link-fallback-secret');
        $visitorHash=hash_hmac('sha256',date('Y-m-d').'|'.$ip,$secret);
        $ua=(string)($_SERVER['HTTP_USER_AGENT']??'');
        [$device,$browser,$os,$isBot]=link_scan_client_details($ua);
        $refHost='';$ref=(string)($_SERVER['HTTP_REFERER']??'');
        if($ref!=='' && filter_var($ref,FILTER_VALIDATE_URL)) $refHost=(string)(parse_url($ref,PHP_URL_HOST)??'');
        if($type==='qr_scan') {
            link_ensure_scan_columns();
            $sourceHash=$ip!==''?hash_hmac('sha256','qr-source|'.$ip,$secret):null;
            $masked=link_mask_ip($ip);
            $q=link_db()->prepare('INSERT INTO analytics_events (event_type,target_id,visitor_hash,referrer_host,device_type,source_hash,ip_masked,user_agent,browser,os_name,is_bot,ip_source) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)');
            $q->execute([$type,$targetId,$visitorHash,$refHost!==''?substr($refHost,0,190):null,$device,$sourceHash,$masked,substr($ua,0,255),$browser,$os,$isBot,$ipSource]);
        } else {
            $q=link_db()->prepare('INSERT INTO analytics_events (event_type,target_id,visitor_hash,referrer_host,device_type) VALUES (?,?,?,?,?)');
            $q->execute([$type,$targetId,$visitorHash,$refHost!==''?substr($refHost,0,190):null,$device]);
        }
    } catch(Throwable $e) {
        // Analytics must never interrupt the visitor's page or redirect.
    }
}
