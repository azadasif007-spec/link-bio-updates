<?php
declare(strict_types=1);

function link_activity_ensure_schema(): void {
    static $done=false;if($done)return;
    link_db()->exec("CREATE TABLE IF NOT EXISTS admin_activity (
      id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      admin_id INT UNSIGNED DEFAULT NULL,
      actor_email VARCHAR(190) DEFAULT NULL,
      action VARCHAR(80) NOT NULL,
      details VARCHAR(500) DEFAULT '',
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_admin_activity_date (created_at),
      INDEX idx_admin_activity_actor (admin_id,created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $done=true;
}
function link_activity_log(string $action,string $details=''): void {
    try {
      link_activity_ensure_schema();
      $q=link_db()->prepare('INSERT INTO admin_activity (admin_id,actor_email,action,details) VALUES (?,?,?,?)');
      $q->execute([isset($_SESSION['link_admin_id'])?(int)$_SESSION['link_admin_id']:null,substr((string)($_SESSION['link_admin_email']??'system'),0,190),substr($action,0,80),substr($details,0,500)]);
    } catch(Throwable $e) { error_log('LINK activity log: '.$e->getMessage()); }
}
