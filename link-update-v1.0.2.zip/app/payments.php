<?php
declare(strict_types=1);

/**
 * LINK Payments - provider-neutral payment requests.
 * Direct UPI is a manual-confirmation method; submitted UTRs are never treated as proof.
 */
function link_payment_ensure_schema(): void {
    static $done=false;
    if($done) return;
    $pdo=link_db();
    $pdo->exec("CREATE TABLE IF NOT EXISTS payment_links (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        code CHAR(32) NOT NULL UNIQUE,
        title VARCHAR(140) NOT NULL,
        description VARCHAR(500) DEFAULT '',
        amount DECIMAL(12,2) NOT NULL,
        currency CHAR(3) NOT NULL DEFAULT 'INR',
        status VARCHAR(20) NOT NULL DEFAULT 'active',
        expires_at DATETIME DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_payment_status_date (status,created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $pdo->exec("CREATE TABLE IF NOT EXISTS payment_submissions (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        payment_link_id BIGINT UNSIGNED NOT NULL,
        customer_name VARCHAR(120) NOT NULL,
        utr VARCHAR(100) NOT NULL,
        customer_note VARCHAR(255) DEFAULT '',
        status VARCHAR(20) NOT NULL DEFAULT 'pending',
        submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        reviewed_at DATETIME DEFAULT NULL,
        UNIQUE KEY uq_payment_utr (utr),
        INDEX idx_payment_submission_status (status,submitted_at),
        CONSTRAINT fk_payment_submission_link FOREIGN KEY (payment_link_id) REFERENCES payment_links(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $pdo->exec("CREATE TABLE IF NOT EXISTS payment_audit (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        payment_link_id BIGINT UNSIGNED DEFAULT NULL,
        action VARCHAR(40) NOT NULL,
        detail VARCHAR(500) DEFAULT '',
        actor VARCHAR(190) DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_payment_audit_date (created_at),
        CONSTRAINT fk_payment_audit_link FOREIGN KEY (payment_link_id) REFERENCES payment_links(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $done=true;
}

function link_payment_valid_upi(string $upi): bool {
    return (bool)preg_match('/^[A-Za-z0-9._-]{2,100}@[A-Za-z0-9.-]{2,64}$/',$upi);
}

function link_payment_log(?int $linkId,string $action,string $detail=''): void {
    $q=link_db()->prepare('INSERT INTO payment_audit (payment_link_id,action,detail,actor) VALUES (?,?,?,?)');
    $q->execute([$linkId,$action,substr($detail,0,500),substr((string)($_SESSION['link_admin_email']??'system'),0,190)]);
}

function link_payment_uri(string $upi,string $payee,string $amount,string $reference): string {
    return 'upi://pay?'.http_build_query([
        'pa'=>$upi,'pn'=>$payee,'am'=>$amount,'cu'=>'INR','tn'=>$reference
    ],'','&',PHP_QUERY_RFC3986);
}
