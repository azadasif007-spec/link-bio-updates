<?php
declare(strict_types=1);

function link_security_ensure_schema(): void {
    static $done=false; if($done)return;
    link_db()->exec("CREATE TABLE IF NOT EXISTS admin_login_attempts (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        identity_hash CHAR(64) NOT NULL,
        attempted_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_login_identity_time (identity_hash,attempted_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    link_db()->exec("CREATE TABLE IF NOT EXISTS admin_security (
        admin_id INT UNSIGNED PRIMARY KEY,
        totp_secret_enc VARCHAR(255) DEFAULT NULL,
        pending_secret_enc VARCHAR(255) DEFAULT NULL,
        recovery_codes_json MEDIUMTEXT DEFAULT NULL,
        totp_enabled TINYINT(1) NOT NULL DEFAULT 0,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        CONSTRAINT fk_admin_security_admin FOREIGN KEY (admin_id) REFERENCES admins(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $cols=array_column(link_db()->query('SHOW COLUMNS FROM admin_security')->fetchAll(),'Field');
    if(!in_array('recovery_codes_json',$cols,true)) link_db()->exec('ALTER TABLE admin_security ADD recovery_codes_json MEDIUMTEXT DEFAULT NULL');
    $done=true;
}
function link_security_identity(string $email): string {
    $ip=(string)($_SERVER['REMOTE_ADDR']??'unknown');
    $cfg=require dirname(__DIR__).'/config/installation.php';
    return hash_hmac('sha256',strtolower(trim($email)).'|'.$ip,(string)$cfg['tracking_secret']);
}
function link_security_locked(string $email): bool {
    link_security_ensure_schema();
    $q=link_db()->prepare('SELECT COUNT(*) FROM admin_login_attempts WHERE identity_hash=? AND attempted_at >= (NOW() - INTERVAL 15 MINUTE)');
    $q->execute([link_security_identity($email)]);
    return (int)$q->fetchColumn()>=8;
}
function link_security_record_failure(string $email): void {
    link_security_ensure_schema();
    $q=link_db()->prepare('INSERT INTO admin_login_attempts (identity_hash) VALUES (?)');
    $q->execute([link_security_identity($email)]);
    if(random_int(1,20)===1) link_db()->exec('DELETE FROM admin_login_attempts WHERE attempted_at < (NOW() - INTERVAL 2 DAY)');
}
function link_security_clear_failures(string $email): void {
    link_security_ensure_schema();
    $q=link_db()->prepare('DELETE FROM admin_login_attempts WHERE identity_hash=?');
    $q->execute([link_security_identity($email)]);
}
function link_security_key(): string {
    $cfg=require dirname(__DIR__).'/config/installation.php';
    return hash_hkdf('sha256',hex2bin((string)$cfg['tracking_secret'])?: (string)$cfg['tracking_secret'],32,'LINK admin TOTP secret','LINK');
}
function link_security_encrypt(string $secret): string {
    $iv=random_bytes(12);$tag='';
    $cipher=openssl_encrypt($secret,'aes-256-gcm',link_security_key(),OPENSSL_RAW_DATA,$iv,$tag,'LINK-TOTP',16);
    if($cipher===false)throw new RuntimeException('Could not protect authenticator secret.');
    return base64_encode($iv.$tag.$cipher);
}
function link_security_decrypt(string $secret): string {
    $raw=base64_decode($secret,true);
    if($raw===false||strlen($raw)<29)throw new RuntimeException('Authenticator secret is invalid.');
    $plain=openssl_decrypt(substr($raw,28),'aes-256-gcm',link_security_key(),OPENSSL_RAW_DATA,substr($raw,0,12),substr($raw,12,16),'LINK-TOTP');
    if($plain===false)throw new RuntimeException('Could not decrypt authenticator secret.');
    return $plain;
}
function link_totp_base32_encode(string $data): string {
    $alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';$bits='';
    foreach(str_split($data) as $c)$bits.=str_pad(decbin(ord($c)),8,'0',STR_PAD_LEFT);
    $out='';foreach(str_split($bits,5) as $chunk)$out.=$alphabet[bindec(str_pad($chunk,5,'0'))];
    return $out;
}
function link_totp_base32_decode(string $value): string {
    $alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';$bits='';
    foreach(str_split(strtoupper(rtrim($value,'='))) as $c){$p=strpos($alphabet,$c);if($p===false)throw new InvalidArgumentException('Invalid authenticator secret.');$bits.=str_pad(decbin($p),5,'0',STR_PAD_LEFT);}
    $out='';foreach(str_split($bits,8) as $chunk)if(strlen($chunk)===8)$out.=chr(bindec($chunk));
    return $out;
}
function link_totp_code(string $secret,?int $time=null): string {
    $counter=intdiv($time??time(),30);$key=link_totp_base32_decode($secret);
    $msg=pack('N*',0).pack('N*',$counter);$hash=hash_hmac('sha1',$msg,$key,true);
    $offset=ord($hash[19])&15;$binary=((ord($hash[$offset])&127)<<24)|((ord($hash[$offset+1])&255)<<16)|((ord($hash[$offset+2])&255)<<8)|(ord($hash[$offset+3])&255);
    return str_pad((string)($binary%1000000),6,'0',STR_PAD_LEFT);
}
function link_totp_verify(string $secret,string $code): bool {
    if(!preg_match('/^[0-9]{6}$/',$code))return false;
    for($i=-1;$i<=1;$i++)if(hash_equals(link_totp_code($secret,time()+($i*30)),$code))return true;
    return false;
}
function link_security_row(int $adminId): array {
    link_security_ensure_schema();$q=link_db()->prepare('SELECT * FROM admin_security WHERE admin_id=?');$q->execute([$adminId]);return $q->fetch()?:[];
}

function link_security_generate_recovery_codes(): array {
    $plain=[];$hashes=[];
    for($i=0;$i<10;$i++){$code=strtoupper(bin2hex(random_bytes(4)));$plain[]=substr($code,0,4).'-'.substr($code,4,4);$hashes[]=password_hash($code,PASSWORD_DEFAULT);}
    return ['plain'=>$plain,'hashes'=>$hashes];
}
function link_security_consume_recovery_code(int $adminId,string $submitted): bool {
    $normal=strtoupper(preg_replace('/[^A-F0-9]/i','',trim($submitted)));
    if(!preg_match('/^[A-F0-9]{8}$/',$normal))return false;
    $pdo=link_db();
    try{
      $pdo->beginTransaction();
      $q=$pdo->prepare('SELECT recovery_codes_json FROM admin_security WHERE admin_id=? AND totp_enabled=1 FOR UPDATE');
      $q->execute([$adminId]);$raw=$q->fetchColumn();
      $hashes=is_string($raw)?json_decode($raw,true):null;
      if(!is_array($hashes)){$pdo->commit();return false;}
      $matched=null;
      foreach($hashes as $i=>$hash)if(is_string($hash)&&password_verify($normal,$hash)){$matched=$i;break;}
      if($matched===null){$pdo->commit();return false;}
      array_splice($hashes,(int)$matched,1);
      $u=$pdo->prepare('UPDATE admin_security SET recovery_codes_json=? WHERE admin_id=?');
      $u->execute([json_encode(array_values($hashes)), $adminId]);
      $pdo->commit();return true;
    }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
}
