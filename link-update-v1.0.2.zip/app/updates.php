<?php
declare(strict_types=1);

const LINK_OTA_MANIFEST_URL='https://github.com/azadasif007-spec/link-bio/releases/latest/download/link-update-manifest.json';
const LINK_OTA_PUBLIC_KEY=<<<'PEM'
-----BEGIN PUBLIC KEY-----
MIIBojANBgkqhkiG9w0BAQEFAAOCAY8AMIIBigKCAYEA5CDBzlg9LKbLxP53Lj1e
aMBnNLGF1vBw+h+kCCKKl5TPt1WOk/Mg9leO+Adf+MaqQ7gLUrK6b9yKmQRGH00Z
lZM6XNzNNRwKeRm9kpk7erscP0oI4QJ5nBIUZ8YR/EZ7gTGTz5f0Lxf4h0kkOz1m
MiN1WSbL8pS92ZJu8kN2kzq79igsItISbx/O1SeOCAVJV7WswbW/IzdudWyI/ZBz
3vQK4Q/2xnYv2bJSgCcThzq+CRbm+W832qJYZYkH4rpwqAb+MURgPzy00cspNjhD
bRvCXLgYV8lCLzUHJTVn3FU2shuKo57pFQmH9f+JgFdE44aABRFD53eGDGIiLBW9
2jffd4h6VjB+lq79h9Q8PIT1nYzDDZW81WQbu4TyWaRljrmD0xWcXMcq+aiusH4z
/ttNEQznEkQHkqpaLzdtszpORAZifDhXnbO6NikbOpq571b3Y6dumCFqeWm9aAkQ
h5ZAa0XrkcXnHGxm5rHygULZjY53/cQiePLyr3jQVpgrAgMBAAE=
-----END PUBLIC KEY-----
PEM;

function link_ota_current_version(): string {
    $v=trim((string)@file_get_contents(dirname(__DIR__).'/VERSION'));
    return preg_match('/^\d+\.\d+\.\d+$/',$v)?$v:'1.0.0';
}
function link_ota_http_get(string $url,int $limit=1048576): string {
    if(!function_exists('curl_init'))throw new RuntimeException('The PHP cURL extension is required for software updates.');
    $ch=curl_init($url);$body='';$tooLarge=false;
    curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>false,CURLOPT_FOLLOWLOCATION=>true,CURLOPT_MAXREDIRS=>3,CURLOPT_CONNECTTIMEOUT=>15,CURLOPT_TIMEOUT=>90,CURLOPT_PROTOCOLS=>CURLPROTO_HTTPS,CURLOPT_REDIR_PROTOCOLS=>CURLPROTO_HTTPS,CURLOPT_USERAGENT=>'LINK-OTA/1.0',CURLOPT_WRITEFUNCTION=>static function($ch,$chunk)use(&$body,&$tooLarge,$limit){if(strlen($body)+strlen($chunk)>$limit){$tooLarge=true;return 0;}$body.=$chunk;return strlen($chunk);}]);
    $ok=curl_exec($ch);$status=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE);$err=curl_error($ch);curl_close($ch);
    if($ok===false||$status<200||$status>=300)throw new RuntimeException($tooLarge?'Downloaded update is too large.':'Could not download update information (HTTP '.$status.'). '.$err);
    return $body;
}
function link_ota_manifest(): array {
    $raw=link_ota_http_get(LINK_OTA_MANIFEST_URL,65536);$m=json_decode($raw,true);
    if(!is_array($m))throw new RuntimeException('The update server returned an invalid manifest.');
    foreach(['version','min_php','sha256','package_url','signature'] as $k)if(!isset($m[$k])||!is_string($m[$k]))throw new RuntimeException('The update manifest is incomplete.');
    if(!preg_match('/^\d+\.\d+\.\d+$/',$m['version'])||!preg_match('/^[a-f0-9]{64}$/',$m['sha256']))throw new RuntimeException('The update manifest contains invalid version or checksum data.');
    $prefix='https://github.com/azadasif007-spec/link-bio/releases/download/';
    if(!str_starts_with($m['package_url'],$prefix)||str_contains($m['package_url'],'..'))throw new RuntimeException('The update package URL is not trusted.');
    $payload="LINK-OTA-V1\n".$m['version']."\n".$m['min_php']."\n".$m['sha256']."\n".$m['package_url'];
    $sig=base64_decode($m['signature'],true);$pub=openssl_pkey_get_public(LINK_OTA_PUBLIC_KEY);
    if($sig===false||$pub===false||openssl_verify($payload,$sig,$pub,OPENSSL_ALGO_SHA256)!==1)throw new RuntimeException('The update signature is invalid. Installation was blocked.');
    if(version_compare(PHP_VERSION,$m['min_php'],'<'))throw new RuntimeException('This update requires PHP '.$m['min_php'].' or newer.');
    return $m;
}
function link_ota_add_tree(ZipArchive $zip,string $root,string $exclude=''): void {
    $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::SELF_FIRST);
    foreach($it as $file){$path=str_replace(DIRECTORY_SEPARATOR,'/',$file->getPathname());$rel=ltrim(substr($path,strlen($root)),'/');
      if($rel===''||preg_match('#^(config/|uploads/|storage/|\.git/|vendor/)#',$rel)||$rel==='.htaccess'&&$exclude==='package')continue;
      if($file->isDir())$zip->addEmptyDir($rel);elseif($file->isFile())$zip->addFile($path,$rel);
    }
}
function link_ota_safe_extract(ZipArchive $zip,string $dest): void {
    $total=0;for($i=0;$i<$zip->numFiles;$i++){$name=$zip->getNameIndex($i);if(!is_string($name)||$name===''||str_starts_with($name,'/')||str_contains($name,'..')||str_contains($name,'\\')||preg_match('/^[A-Za-z]:/',$name))throw new RuntimeException('The update archive contains an unsafe path.');
      if($i>1500)throw new RuntimeException('The update archive contains too many files.');
      $clean=rtrim($name,'/');if($clean===''||preg_match('#^(config|uploads|storage|\.git|vendor)(/|$)#',$clean)||$clean==='config/installation.php')throw new RuntimeException('The update archive attempts to replace protected installation data.');
      $stat=$zip->statIndex($i);$total+=(int)($stat['size']??0);if(($stat['size']??0)>25*1024*1024||$total>100*1024*1024)throw new RuntimeException('The update archive exceeds the permitted expanded size.');
    }
    if(!$zip->extractTo($dest))throw new RuntimeException('Could not extract the update package.');
}
function link_ota_install(): string {
    if(!class_exists('ZipArchive'))throw new RuntimeException('The PHP ZIP extension is required for software updates.');
    $m=link_ota_manifest();$current=link_ota_current_version();
    if(version_compare($m['version'],$current,'<='))throw new RuntimeException('No newer version is available.');
    $root=dirname(__DIR__);$tmp=$root.'/storage/ota-'.bin2hex(random_bytes(8));$stage=$tmp.'/stage';$backupDir=$root.'/storage/backups';
    if(!is_dir($root.'/storage')&&!mkdir($root.'/storage',0750,true)&&!is_dir($root.'/storage'))throw new RuntimeException('Private storage folder is unavailable.');
    if(!mkdir($tmp,0750,true)||!mkdir($stage,0750,true))throw new RuntimeException('Could not create a temporary update folder.');
    $backupPath=$backupDir.'/link-code-'.$current.'-'.gmdate('Ymd-His').'.zip';
    try{
      $package=link_ota_http_get($m['package_url'],104857600);
      if(!hash_equals($m['sha256'],hash('sha256',$package)))throw new RuntimeException('Update package checksum does not match the signed manifest.');
      $packagePath=$tmp.'/update.zip';if(file_put_contents($packagePath,$package,LOCK_EX)===false)throw new RuntimeException('Could not save the update package.');
      $zip=new ZipArchive();if($zip->open($packagePath)!==true)throw new RuntimeException('The update package is not a valid ZIP archive.');
      link_ota_safe_extract($zip,$stage);$zip->close();
      $packageVersion=trim((string)@file_get_contents($stage.'/VERSION'));if(!hash_equals($m['version'],$packageVersion))throw new RuntimeException('Package version does not match the signed manifest.');
      if(!is_dir($backupDir)&&!mkdir($backupDir,0750,true)&&!is_dir($backupDir))throw new RuntimeException('Private backup folder is unavailable.');
      $backup=new ZipArchive();if($backup->open($backupPath,ZipArchive::CREATE|ZipArchive::OVERWRITE)!==true)throw new RuntimeException('Could not create a pre-update code backup.');
      link_ota_add_tree($backup,$root);$backup->close();
      $iterator=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($stage,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::SELF_FIRST);
      foreach($iterator as $item){$rel=str_replace(DIRECTORY_SEPARATOR,'/',substr($item->getPathname(),strlen($stage)+1));if(preg_match('#^(config/|uploads/|storage/|\.git/|vendor/)#',$rel))continue;$target=$root.'/'.$rel;
        if($item->isDir()){if(!is_dir($target)&&!mkdir($target,0755,true)&&!is_dir($target))throw new RuntimeException('Could not create update directory: '.$rel);}
        else{$dir=dirname($target);if(!is_dir($dir)&&!mkdir($dir,0755,true)&&!is_dir($dir))throw new RuntimeException('Could not create update directory.');$new=$target.'.ota-'.bin2hex(random_bytes(4));if(!copy($item->getPathname(),$new)||!rename($new,$target))throw new RuntimeException('Could not install update file: '.$rel);}
      }
      $installed=link_ota_current_version();if(!hash_equals($m['version'],$installed))throw new RuntimeException('Post-update version check failed.');
      @unlink($packagePath);link_activity_log('software_updated','Updated LINK from '.$current.' to '.$installed);
      return 'LINK updated successfully to version '.$installed.'. Your profile data, database credentials, uploads and payment settings were preserved.';
    }catch(Throwable $e){
      if(is_file($backupPath)){try{$restore=new ZipArchive();if($restore->open($backupPath)===true){$oldFiles=[];for($i=0;$i<$restore->numFiles;$i++)$oldFiles[$restore->getNameIndex($i)]=true;$restore->extractTo($root);$restore->close();$it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($stage,FilesystemIterator::SKIP_DOTS));foreach($it as $f){if(!$f->isFile())continue;$rel=str_replace(DIRECTORY_SEPARATOR,'/',substr($f->getPathname(),strlen($stage)+1));if(!isset($oldFiles[$rel]))@unlink($root.'/'.$rel);}}}catch(Throwable $rollbackError){error_log('LINK OTA rollback failed: '.$rollbackError->getMessage());}}
      throw $e;
    }finally{
      if(is_dir($tmp)){$it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($tmp,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::CHILD_FIRST);foreach($it as $f){$f->isDir()?@rmdir($f->getPathname()):@unlink($f->getPathname());}@rmdir($tmp);}
    }
}
