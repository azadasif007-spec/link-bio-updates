<?php
declare(strict_types=1);
require_once __DIR__.'/payments.php';

/** Encryption key is derived from the installation-specific secret, never from a user password. */
function link_gateway_key(): string {
    $cfg=require dirname(__DIR__).'/config/installation.php';
    $secret=(string)($cfg['tracking_secret']??'');
    if(strlen($secret)<32) throw new RuntimeException('Installation encryption secret is unavailable.');
    return hash_hkdf('sha256',hex2bin($secret)?:$secret,32,'LINK payment gateway credentials','LINK');
}
function link_gateway_encrypt(string $plain): string {
    if(!function_exists('openssl_encrypt')) throw new RuntimeException('OpenSSL is required to store gateway credentials securely.');
    $iv=random_bytes(12);$tag='';
    $cipher=openssl_encrypt($plain,'aes-256-gcm',link_gateway_key(),OPENSSL_RAW_DATA,$iv,$tag,'LINK-GATEWAY',16);
    if($cipher===false) throw new RuntimeException('Could not encrypt gateway credential.');
    return base64_encode($iv.$tag.$cipher);
}
function link_gateway_decrypt(string $encoded): string {
    $raw=base64_decode($encoded,true);
    if($raw===false||strlen($raw)<29) throw new RuntimeException('Stored gateway credential is invalid.');
    $plain=openssl_decrypt(substr($raw,28),'aes-256-gcm',link_gateway_key(),OPENSSL_RAW_DATA,substr($raw,0,12),substr($raw,12,16),'LINK-GATEWAY');
    if($plain===false) throw new RuntimeException('Could not decrypt gateway credential.');
    return $plain;
}
function link_gateway_save_credentials(string $provider,array $values): void {
    $allowed=['razorpay'=>['key_id','key_secret','webhook_secret'],'cashfree'=>['app_id','secret_key','webhook_secret']];
    if(!isset($allowed[$provider])) throw new InvalidArgumentException('Unknown gateway.');
    foreach($allowed[$provider] as $key) {
        $value=trim((string)($values[$key]??''));
        if($value!=='') link_save_setting('gateway_'.$provider.'_'.$key.'_enc',link_gateway_encrypt($value));
    }
    link_save_setting('gateway_'.$provider.'_environment',($values['environment']??'sandbox')==='live'?'live':'sandbox');
    link_save_setting('gateway_'.$provider.'_enabled',!empty($values['enabled'])?'1':'0');
    link_payment_log(null,$provider.'_credentials_updated','Gateway configuration updated; secrets are encrypted at rest.');
}
function link_gateway_credentials(string $provider): array {
    $allowed=['razorpay'=>['key_id','key_secret','webhook_secret'],'cashfree'=>['app_id','secret_key','webhook_secret']];
    if(!isset($allowed[$provider])) throw new InvalidArgumentException('Unknown gateway.');
    $out=['environment'=>link_setting('gateway_'.$provider.'_environment','sandbox'),'enabled'=>link_setting('gateway_'.$provider.'_enabled','0')==='1'];
    foreach($allowed[$provider] as $key) {
        $stored=link_setting('gateway_'.$provider.'_'.$key.'_enc','');
        $out[$key]=$stored!==''?link_gateway_decrypt($stored):'';
    }
    return $out;
}
function link_gateway_ready(string $provider): bool {
    try {
        $c=link_gateway_credentials($provider);
        if(!$c['enabled']) return false;
        if($provider==='razorpay') return $c['key_id']!==''&&$c['key_secret']!==''&&$c['webhook_secret']!=='';
        return $c['app_id']!==''&&$c['secret_key']!==''&&$c['webhook_secret']!=='';
    } catch(Throwable $e) { return false; }
}
function link_gateway_http(string $method,string $url,array $headers=[],?array $json=null,?array $basic=null): array {
    if(!function_exists('curl_init')) throw new RuntimeException('PHP cURL extension is required for gateway payments.');
    $ch=curl_init($url);$h=$headers;
    if($json!==null)$h[]='Content-Type: application/json';
    if($basic!==null)$h[]='Authorization: Basic '.base64_encode($basic[0].':'.$basic[1]);
    curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_CUSTOMREQUEST=>$method,CURLOPT_HTTPHEADER=>$h,CURLOPT_CONNECTTIMEOUT=>10,CURLOPT_TIMEOUT=>25,CURLOPT_POSTFIELDS=>$json!==null?json_encode($json,JSON_UNESCAPED_SLASHES):null,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2]);
    $body=curl_exec($ch);$status=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);$err=curl_error($ch);curl_close($ch);
    if($body===false) throw new RuntimeException('Gateway connection failed: '.$err);
    $data=json_decode((string)$body,true);
    if($status<200||$status>=300||!is_array($data)) throw new RuntimeException('Gateway API error (HTTP '.$status.'). Check provider dashboard and credentials.');
    return $data;
}
function link_gateway_ensure_schema(): void {
    link_payment_ensure_schema();
    $pdo=link_db();
    $pdo->exec("CREATE TABLE IF NOT EXISTS gateway_transactions (
      id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      payment_link_id BIGINT UNSIGNED NOT NULL,
      provider VARCHAR(20) NOT NULL,
      local_order_id VARCHAR(64) NOT NULL UNIQUE,
      provider_order_id VARCHAR(120) DEFAULT NULL,
      provider_payment_id VARCHAR(120) DEFAULT NULL,
      checkout_url TEXT DEFAULT NULL,
      payment_session_id TEXT DEFAULT NULL,
      amount DECIMAL(12,2) NOT NULL,
      currency CHAR(3) NOT NULL DEFAULT 'INR',
      status VARCHAR(24) NOT NULL DEFAULT 'created',
      method VARCHAR(40) DEFAULT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      paid_at DATETIME DEFAULT NULL,
      INDEX idx_gateway_payment_link (payment_link_id,created_at),
      INDEX idx_gateway_provider_ref (provider,provider_order_id),
      CONSTRAINT fk_gateway_payment_link FOREIGN KEY (payment_link_id) REFERENCES payment_links(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $pdo->exec("CREATE TABLE IF NOT EXISTS gateway_webhook_events (
      id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      provider VARCHAR(20) NOT NULL,
      event_key VARCHAR(190) NOT NULL,
      event_type VARCHAR(100) DEFAULT NULL,
      processed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      UNIQUE KEY uq_gateway_event (provider,event_key)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}
function link_gateway_create_razorpay(int $paymentLinkId,string $title,string $description,float $amount,string $currency,string $localOrder,array $customer=[]): array {
    $c=link_gateway_credentials('razorpay');
    $payload=['amount'=>(int)round($amount*100),'currency'=>$currency,'accept_partial'=>false,'reference_id'=>$localOrder,'description'=>substr($title.($description!==''?' - '.$description:''),0,255),'customer'=>array_filter(['name'=>substr((string)($customer['name']??''),0,120),'contact'=>substr((string)($customer['phone']??''),0,20),'email'=>substr((string)($customer['email']??''),0,190)]),'notify'=>['sms'=>false,'email'=>false],'reminder_enable'=>false,'notes'=>['link_order'=>$localOrder]];
    $data=link_gateway_http('POST','https://api.razorpay.com/v1/payment_links/',['Accept: application/json'],$payload,[$c['key_id'],$c['key_secret']]);
    if(empty($data['id'])||empty($data['short_url'])) throw new RuntimeException('Razorpay did not return a hosted payment link.');
    return ['provider_order_id'=>$data['id'],'checkout_url'=>$data['short_url'],'payment_session_id'=>null];
}
function link_gateway_create_cashfree(int $paymentLinkId,string $title,float $amount,string $currency,string $localOrder,array $customer=[]): array {
    $c=link_gateway_credentials('cashfree');$base=$c['environment']==='live'?'https://api.cashfree.com/pg':'https://sandbox.cashfree.com/pg';
    $host=(string)($_SERVER['HTTP_HOST']??'');$scheme=(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off')?'https':'https';
    $payload=['order_id'=>$localOrder,'order_amount'=>round($amount,2),'order_currency'=>$currency,'customer_details'=>['customer_id'=>'link_'.substr(hash('sha256',$localOrder),0,20),'customer_phone'=>substr(preg_replace('/[^0-9]/','',(string)($customer['phone']??'')),-10),'customer_email'=>substr((string)($customer['email']??''),0,190),'customer_name'=>substr((string)($customer['name']??''),0,120)],'order_meta'=>['return_url'=>$scheme.'://'.$host.'/gateway-return.php?provider=cashfree&order_id='.$localOrder,'notify_url'=>$scheme.'://'.$host.'/gateway-webhook.php?provider=cashfree']];
    $data=link_gateway_http('POST',$base.'/orders/',['x-client-id: '.$c['app_id'],'x-client-secret: '.$c['secret_key'],'x-api-version: 2025-01-01','x-request-id: '.$localOrder],$payload);
    if(empty($data['cf_order_id'])||empty($data['payment_session_id'])) throw new RuntimeException('Cashfree did not return a payment session.');
    return ['provider_order_id'=>(string)$data['cf_order_id'],'checkout_url'=>null,'payment_session_id'=>$data['payment_session_id']];
}
function link_gateway_verify_webhook(string $provider,string $raw,array $headers): bool {
    $c=link_gateway_credentials($provider);
    if($provider==='razorpay'){
        $sig=(string)($headers['x-razorpay-signature']??'');
        return $sig!==''&&preg_match('/^[a-f0-9]{64}$/i',$sig)&&hash_equals(hash_hmac('sha256',$raw,$c['webhook_secret']),strtolower($sig));
    }
    $sig=(string)($headers['x-webhook-signature']??'');$ts=(string)($headers['x-webhook-timestamp']??'');
    if($sig===''||$ts===''||!ctype_digit($ts)||abs(time()-(int)$ts)>86400)return false;
    return hash_equals(base64_encode(hash_hmac('sha256',$ts.$raw,$c['webhook_secret'],true)),$sig);
}
function link_gateway_mark_paid(string $provider,string $providerOrderId,string $paymentId,string $method='',?float $amount=null,string $currency='INR'): bool {
    $pdo=link_db();
    $q=$pdo->prepare("SELECT * FROM gateway_transactions WHERE provider=? AND provider_order_id=? LIMIT 1");
    $q->execute([$provider,$providerOrderId]);$tx=$q->fetch();
    if(!$tx)return false;
    if($amount!==null && (abs((float)$tx['amount']-$amount)>0.009 || strtoupper((string)$tx['currency'])!==strtoupper($currency))) return false;
    if($tx['status']==='paid')return true;
    $u=$pdo->prepare("UPDATE gateway_transactions SET status='paid',provider_payment_id=?,method=?,paid_at=NOW() WHERE id=? AND status<>'paid'");
    $u->execute([$paymentId,$method,(int)$tx['id']]);
    link_payment_log((int)$tx['payment_link_id'],$provider.'_payment_paid','Provider payment confirmed by signed webhook.');
    return true;
}

function link_gateway_update_status(string $provider,string $providerOrderId,string $status,string $paymentId='',string $method=''): bool {
    $allowed=['pending','failed','cancelled','expired','refunded'];
    if(!in_array($status,$allowed,true))return false;
    $pdo=link_db();
    $q=$pdo->prepare("SELECT id,payment_link_id,status FROM gateway_transactions WHERE provider=? AND provider_order_id=? LIMIT 1");
    $q->execute([$provider,$providerOrderId]);$tx=$q->fetch();
    if(!$tx||$tx['status']==='paid')return false;
    $u=$pdo->prepare("UPDATE gateway_transactions SET status=?,provider_payment_id=COALESCE(NULLIF(?,''),provider_payment_id),method=COALESCE(NULLIF(?,''),method) WHERE id=? AND status<>'paid'");
    $u->execute([$status,$paymentId,$method,(int)$tx['id']]);
    if($u->rowCount())link_payment_log((int)$tx['payment_link_id'],$provider.'_payment_'.$status,'Provider reported transaction status: '.$status);
    return $u->rowCount()>0;
}

function link_gateway_mark_refunded(string $provider,string $providerOrderId,string $paymentId=''): bool {
    $pdo=link_db();$q=$pdo->prepare('SELECT id,payment_link_id,status FROM gateway_transactions WHERE provider=? AND provider_order_id=? LIMIT 1');$q->execute([$provider,$providerOrderId]);$tx=$q->fetch();
    if(!$tx||$tx['status']!=='paid')return false;
    $u=$pdo->prepare("UPDATE gateway_transactions SET status='refunded',provider_payment_id=COALESCE(NULLIF(?,''),provider_payment_id) WHERE id=? AND status='paid'");
    $u->execute([$paymentId,(int)$tx['id']]);
    if($u->rowCount())link_payment_log((int)$tx['payment_link_id'],$provider.'_payment_refunded','Provider confirmed refund status.');
    return $u->rowCount()>0;
}
