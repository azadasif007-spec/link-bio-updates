<?php
declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.cookie_httponly', '1');
    $secure = (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off')
        || (strtolower((string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https');
    session_set_cookie_params(['httponly'=>true,'secure'=>$secure,'samesite'=>'Lax']);
    session_start();
    if (!empty($_SESSION['link_admin_id'])) {
        $last=(int)($_SESSION['link_admin_last_activity']??time());
        if(time()-$last>1800) {
            $_SESSION=[];
            session_regenerate_id(true);
        } else {
            $_SESSION['link_admin_last_activity']=time();
        }
    }
}

function link_app_installed(): bool {
    return is_file(dirname(__DIR__) . '/config/installation.php');
}
function link_db(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;
    $file = dirname(__DIR__) . '/config/installation.php';
    if (!is_file($file)) { header('Location: install/'); exit; }
    $cfg = require $file;
    $dsn = sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4', $cfg['db_host'], $cfg['db_name']);
    $pdo = new PDO($dsn, $cfg['db_user'], $cfg['db_pass'], [
        PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES=>false,
    ]);
    return $pdo;
}
function link_e(?string $value): string { return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function link_csrf_token(): string {
    if (empty($_SESSION['link_csrf'])) $_SESSION['link_csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['link_csrf'];
}
function link_verify_csrf(): void {
    $sent = (string)($_POST['_csrf'] ?? '');
    if ($sent === '' || !hash_equals(link_csrf_token(), $sent)) {
        http_response_code(419); exit('Your session expired. Please go back and try again.');
    }
}
function link_require_admin(): void {
    if (empty($_SESSION['link_admin_id'])) { header('Location: index.php'); exit; }
}
function link_setting(string $key, string $default = ''): string {
    $stmt = link_db()->prepare('SELECT setting_value FROM settings WHERE setting_key = ? LIMIT 1');
    $stmt->execute([$key]);
    $value = $stmt->fetchColumn();
    return $value === false ? $default : (string)$value;
}
function link_save_setting(string $key, string $value): void {
    $stmt = link_db()->prepare('INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)');
    $stmt->execute([$key, $value]);
}
