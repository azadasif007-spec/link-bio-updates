<?php
declare(strict_types=1);
require_once dirname(__DIR__) . '/app/bootstrap.php';

$configPath = dirname(__DIR__) . '/config/installation.php';
if (is_file($configPath)) { http_response_code(403); exit('LINK is already installed.'); }
$error = '';
$done = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    link_verify_csrf();
    $host = trim((string)($_POST['db_host'] ?? 'localhost'));
    $name = trim((string)($_POST['db_name'] ?? ''));
    $user = trim((string)($_POST['db_user'] ?? ''));
    $pass = (string)($_POST['db_pass'] ?? '');
    $adminEmail = trim((string)($_POST['admin_email'] ?? ''));
    $adminPass = (string)($_POST['admin_password'] ?? '');
    $profileName = trim((string)($_POST['profile_name'] ?? 'Your Name'));
    if ($name === '' || $user === '' || !filter_var($adminEmail, FILTER_VALIDATE_EMAIL) || strlen($adminPass) < 12) {
        $error = 'Enter database details, a valid admin email and a password of at least 12 characters.';
    } else {
        try {
            $pdo = new PDO(sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4',$host,$name),$user,$pass,[
                PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES=>false,
            ]);
            $schema = [
                "CREATE TABLE IF NOT EXISTS admins (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, email VARCHAR(190) NOT NULL UNIQUE, password_hash VARCHAR(255) NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
                "CREATE TABLE IF NOT EXISTS settings (setting_key VARCHAR(100) PRIMARY KEY, setting_value TEXT NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
                "CREATE TABLE IF NOT EXISTS links (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, label VARCHAR(120) NOT NULL, url VARCHAR(2048) NOT NULL, description VARCHAR(255) DEFAULT '', icon VARCHAR(60) DEFAULT 'link', sort_order INT NOT NULL DEFAULT 0, is_active TINYINT(1) NOT NULL DEFAULT 1, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, INDEX idx_links_active_sort (is_active, sort_order)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
                "CREATE TABLE IF NOT EXISTS qr_codes (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, code VARCHAR(64) NOT NULL UNIQUE, name VARCHAR(120) NOT NULL, destination_url VARCHAR(2048) NOT NULL, color_dark CHAR(6) NOT NULL DEFAULT '17362b', color_light CHAR(6) NOT NULL DEFAULT 'ffffff', is_active TINYINT(1) NOT NULL DEFAULT 1, scans BIGINT UNSIGNED NOT NULL DEFAULT 0, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
                "CREATE TABLE IF NOT EXISTS analytics_events (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, event_type VARCHAR(20) NOT NULL, target_id BIGINT UNSIGNED DEFAULT NULL, visitor_hash CHAR(64) DEFAULT NULL, referrer_host VARCHAR(190) DEFAULT NULL, device_type VARCHAR(20) DEFAULT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, INDEX idx_event_type_date (event_type, created_at), INDEX idx_visitor_hash (visitor_hash)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            ];
            foreach ($schema as $sql) $pdo->exec($sql);
            $stmt=$pdo->prepare('INSERT INTO admins (email,password_hash) VALUES (?,?)');
            $stmt->execute([$adminEmail,password_hash($adminPass,PASSWORD_DEFAULT)]);
            $defaults = [
                'name'=>$profileName,'eyebrow'=>'WELCOME TO MY DIGITAL SPACE',
                'header_mark'=>'L','header_label'=>'MY DIGITAL SPACE',
                'footer_credit'=>'POWERED BY LINK','footer_credit_url'=>'https://link.uikgroup.com',
                'headline'=>'Everything you need, in one place.',
                'bio'=>'A short introduction about you, your work and what you do.',
                'location'=>'','avatar'=>'assets/images/avatar-placeholder.svg',
                'accent'=>'#c5a46d','theme'=>'forest'
            ];
            $ins=$pdo->prepare('INSERT INTO settings (setting_key,setting_value) VALUES (?,?)');
            foreach($defaults as $k=>$v) $ins->execute([$k,$v]);
            $example = require dirname(__DIR__) . '/config/profile.example.php';
            $linkStmt=$pdo->prepare('INSERT INTO links (label,url,description,icon,sort_order,is_active) VALUES (?,?,?,?,?,?)');
            foreach(($example['links'] ?? []) as $i=>$link) $linkStmt->execute([$link['label'],$link['url'],$link['description'] ?? '',$link['icon'] ?? 'link',$i,empty($link['enabled'])?0:1]);
            $config = "<?php\nreturn " . var_export(['db_host'=>$host,'db_name'=>$name,'db_user'=>$user,'db_pass'=>$pass,'tracking_secret'=>bin2hex(random_bytes(32))],true) . ";\n";
            if (file_put_contents($configPath,$config,LOCK_EX) === false) throw new RuntimeException('Could not write config/installation.php. Check folder permissions.');
            @chmod($configPath,0600);
            $done=true;
        } catch(Throwable $e) { error_log('LINK installation failed: '.$e->getMessage()); $error='Installation could not be completed. Check the database details and folder permissions, then try again. If the problem continues, check the server error log.'; }
    }
}
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Install LINK</title><link rel="stylesheet" href="../assets/css/admin.css"></head><body class="admin-body"><main class="setup-wrap"><div class="setup-brand">L<span>·</span> LINK</div><section class="setup-card"><p class="eyebrow">FIRST-TIME SETUP</p><h1>Make this link yours.</h1><p class="muted">Connect your database and create your administrator account.</p>
<?php if($done): ?><div class="notice success">Installation completed. <a href="../admin/">Open your admin panel</a>.</div>
<?php else: ?><?php if($error!==''): ?><div class="notice error"><?=link_e($error)?></div><?php endif; ?>
<form method="post" autocomplete="off"><input type="hidden" name="_csrf" value="<?=link_e(link_csrf_token())?>"><h2>Database connection</h2><div class="form-grid"><label>Database host<input name="db_host" value="localhost" required></label><label>Database name<input name="db_name" required></label><label>Database username<input name="db_user" required></label><label>Database password<input type="password" name="db_pass"></label></div><h2>Administrator</h2><div class="form-grid"><label>Admin email<input type="email" name="admin_email" required></label><label>Strong password <small>12+ characters</small><input type="password" name="admin_password" minlength="12" required></label></div><h2>Profile starter</h2><label>Display name<input name="profile_name" value="Your Name" required></label><button class="primary-btn" type="submit">Install LINK <span>→</span></button></form><?php endif; ?></section><p class="setup-foot">LINK · ONE LINK. YOUR ENTIRE DIGITAL IDENTITY.</p></main></body></html>
