<?php
declare(strict_types=1);
require_once __DIR__.'/app/bootstrap.php';
require_once __DIR__.'/app/payment_gateways.php';
if(!link_app_installed()){http_response_code(404);exit;}
link_gateway_ensure_schema();
$provider=(string)($_GET['provider']??'');$order=trim((string)($_GET['order_id']??''));
$status='pending';$message='We are checking your payment status with the payment provider. This page is not proof of payment.';
if($provider==='cashfree'&&preg_match('/^lnk[a-f0-9]{24}$/',$order)&&link_gateway_ready('cashfree')){
    try{
        $c=link_gateway_credentials('cashfree');$base=$c['environment']==='live'?'https://api.cashfree.com/pg':'https://sandbox.cashfree.com/pg';
        $headers=['x-client-id: '.$c['app_id'],'x-client-secret: '.$c['secret_key'],'x-api-version: 2025-01-01'];
        $ord=link_gateway_http('GET',$base.'/orders/'.rawurlencode($order),$headers);
        $payments=link_gateway_http('GET',$base.'/orders/'.rawurlencode($order).'/payments',$headers);
        foreach($payments as $payment){
            if(strtoupper((string)($payment['payment_status']??''))==='SUCCESS'){
                $ok=link_gateway_mark_paid('cashfree',$order,(string)($payment['cf_payment_id']??''),(string)($payment['payment_group']??''),(float)($payment['payment_amount']??0),(string)($payment['payment_currency']??'INR'));
                if($ok){$status='paid';$message='Payment confirmed by Cashfree. Thank you.';break;}
            }
        }
        if($status!=='paid'&&strtoupper((string)($ord['order_status']??''))==='PAID'){$message='Cashfree reports the order as paid, but payment details are still being reconciled. Please refresh shortly.';}
    }catch(Throwable $e){error_log('LINK Cashfree return verification: '.$e->getMessage());}
}
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Payment status · LINK</title><style>body{font-family:Arial,sans-serif;background:#f3f4ef;color:#17251f;margin:0}.card{max-width:480px;margin:12vh auto;background:#fff;padding:32px;border-radius:16px;box-shadow:0 12px 40px #0001}h1{font:28px Georgia,serif}.muted{color:#6f7d73;line-height:1.6;font-size:14px}.state{padding:12px;border-radius:8px;background:<?=json_encode($status==='paid'?'#e9f3eb':'#fff4e5')?>;color:<?=json_encode($status==='paid'?'#2e6840':'#81551f')?>}</style></head><body><main class="card"><p style="letter-spacing:2px;color:#a98755;font-size:10px;font-weight:bold">LINK PAYMENTS</p><h1><?= $status==='paid'?'Payment successful':'Payment status' ?></h1><p class="state"><?=link_e($message)?></p><p class="muted">If your payment was debited but is not confirmed here, please contact the merchant with your provider transaction reference. Do not pay again until the merchant checks the transaction.</p></main></body></html>